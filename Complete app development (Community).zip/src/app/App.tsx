import { useState } from "react";
import { ThemeProvider } from "next-themes";
import { Toaster } from "sonner";
import { LayoutDashboard, Phone } from "lucide-react";
import { AdminPanel } from "../admin/AdminPanel";
import { MobileApp } from "../mobile/MobileApp";
import { useBookings, useProfessionals, useCustomers, useActivityLog } from "../lib/storage";

export default function App() {
  const [mode, setMode] = useState<"admin" | "mobile">("admin");

  const { bookings, setBookings, addBooking, updateBooking } = useBookings();
  const {
    professionals, setProfessionals,
    addProfessional, updateProfessional, removeProfessional,
  } = useProfessionals();
  const { customers } = useCustomers();
  const { logs, addLog } = useActivityLog();

  return (
    <ThemeProvider attribute="class" defaultTheme="light" enableSystem={false}>
      <Toaster position="top-right" richColors closeButton />

      {/* Mode toggle */}
      <div className="fixed top-4 right-4 z-[300] flex items-center gap-1 bg-white dark:bg-slate-800 border border-border rounded-2xl p-1 shadow-lg">
        <button
          onClick={() => setMode("admin")}
          className={`flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-medium transition-all ${
            mode === "admin" ? "bg-primary text-white" : "text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700"
          }`}
        >
          <LayoutDashboard size={15} /> Admin
        </button>
        <button
          onClick={() => setMode("mobile")}
          className={`flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-medium transition-all ${
            mode === "mobile" ? "bg-slate-900 text-white" : "text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700"
          }`}
        >
          <Phone size={15} /> Mobile
        </button>
      </div>

      {mode === "admin" ? (
        <AdminPanel
          bookings={bookings}
          updateBooking={updateBooking}
          professionals={professionals}
          setProfessionals={setProfessionals}
          addProfessional={addProfessional}
          updateProfessional={updateProfessional}
          removeProfessional={removeProfessional}
          customers={customers}
          logs={logs}
          addLog={addLog}
        />
      ) : (
        <MobileApp
          bookings={bookings}
          addBooking={addBooking}
          professionals={professionals}
          addLog={addLog}
        />
      )}
    </ThemeProvider>
  );
}
