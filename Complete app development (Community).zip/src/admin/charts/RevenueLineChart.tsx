import { useMemo } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Area, AreaChart } from "recharts";
import { format, subDays } from "date-fns";
import type { Booking } from "../../lib/types";
import { TODAY } from "../../lib/utils";

export function RevenueLineChart({ bookings }: { bookings: Booking[] }) {
  const data = useMemo(() => {
    let cumulative = 0;
    return Array.from({ length: 14 }, (_, i) => {
      const date = format(subDays(new Date(TODAY), 13 - i), "yyyy-MM-dd");
      const label = format(subDays(new Date(TODAY), 13 - i), "dd MMM");
      const daily = bookings
        .filter(b => b.date === date && b.status === "Completed")
        .reduce((sum, b) => sum + b.amount, 0);
      cumulative += daily;
      return { label, daily, cumulative };
    });
  }, [bookings]);

  return (
    <div className="bg-white dark:bg-slate-800 rounded-2xl border border-border p-5 shadow-sm">
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="font-semibold text-slate-900 dark:text-slate-100">Revenue — Last 14 Days</h3>
          <p className="text-xs text-slate-500">Completed bookings only</p>
        </div>
        <div className="text-right">
          <p className="text-xl font-bold text-slate-900 dark:text-slate-100">
            ₹{data[data.length - 1]?.cumulative.toLocaleString()}
          </p>
          <p className="text-xs text-emerald-600">cumulative</p>
        </div>
      </div>
      <ResponsiveContainer width="100%" height={180}>
        <AreaChart data={data} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
          <defs>
            <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#2563eb" stopOpacity={0.15} />
              <stop offset="95%" stopColor="#2563eb" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
          <XAxis dataKey="label" tick={{ fontSize: 10, fill: "#94a3b8" }} axisLine={false} tickLine={false} interval={1} />
          <YAxis tick={{ fontSize: 10, fill: "#94a3b8" }} axisLine={false} tickLine={false} tickFormatter={v => `₹${v}`} />
          <Tooltip
            contentStyle={{ borderRadius: "12px", border: "1px solid #e2e8f0", fontSize: 12 }}
            formatter={(value: number, name: string) => [`₹${value.toLocaleString()}`, name === "cumulative" ? "Cumulative" : "Daily"]}
          />
          <Area type="monotone" dataKey="cumulative" stroke="#2563eb" strokeWidth={2} fill="url(#revenueGradient)" dot={false} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
