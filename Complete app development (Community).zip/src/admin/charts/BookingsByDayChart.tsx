import { useMemo } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { format, subDays } from "date-fns";
import type { Booking } from "../../lib/types";
import { TODAY } from "../../lib/utils";

export function BookingsByDayChart({ bookings }: { bookings: Booking[] }) {
  const data = useMemo(() => {
    const days = Array.from({ length: 7 }, (_, i) => {
      const date = format(subDays(new Date(TODAY), 6 - i), "yyyy-MM-dd");
      const label = format(subDays(new Date(TODAY), 6 - i), "dd MMM");
      const count = bookings.filter(b => b.date === date).length;
      return { date, label, count };
    });
    return days;
  }, [bookings]);

  return (
    <div className="bg-white dark:bg-slate-800 rounded-2xl border border-border p-5 shadow-sm">
      <h3 className="font-semibold text-slate-900 dark:text-slate-100 mb-1">Bookings — Last 7 Days</h3>
      <p className="text-xs text-slate-500 mb-4">Daily booking volume</p>
      <ResponsiveContainer width="100%" height={200}>
        <BarChart data={data} barSize={28} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
          <XAxis dataKey="label" tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
          <YAxis tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false} allowDecimals={false} />
          <Tooltip
            contentStyle={{ borderRadius: "12px", border: "1px solid #e2e8f0", fontSize: 12 }}
            cursor={{ fill: "#eff6ff" }}
            formatter={(value: number) => [value, "Bookings"]}
          />
          <Bar dataKey="count" fill="#2563eb" radius={[6, 6, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
