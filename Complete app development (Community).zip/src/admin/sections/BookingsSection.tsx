import { useMemo, useState } from "react";
import { Eye } from "lucide-react";
import type { Booking, Professional, Customer, BookingStatus } from "../../lib/types";
import { statusConfig, tradeColors } from "../../lib/utils";

type Props = {
  bookings: Booking[];
  getCustomer: (id: string) => Customer | undefined;
  getPro: (id: string | null) => Professional | undefined;
  onAssign: (b: Booking) => void;
  onView: (b: Booking) => void;
  onStatusChange: (id: string, status: BookingStatus) => void;
};

const FILTERS: (BookingStatus | "All")[] = ["All", "Pending", "Assigned", "In Progress", "Completed", "Cancelled"];

export function BookingsSection({ bookings, getCustomer, getPro, onAssign, onView, onStatusChange }: Props) {
  const [filter, setFilter] = useState<BookingStatus | "All">("All");
  const [search, setSearch] = useState("");

  const filtered = useMemo(() => {
    let result = filter === "All" ? bookings : bookings.filter(b => b.status === filter);
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(b =>
        b.id.toLowerCase().includes(q) ||
        b.service.toLowerCase().includes(q) ||
        b.category.toLowerCase().includes(q) ||
        getCustomer(b.customerId)?.name.toLowerCase().includes(q)
      );
    }
    return [...result].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [bookings, filter, search, getCustomer]);

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-3">
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search by ID, service, customer…"
          className="w-full sm:w-64 rounded-xl border border-border px-4 py-2.5 text-sm bg-white dark:bg-slate-800 dark:text-slate-100 outline-none focus:ring-2 focus:ring-ring"
        />
        <div className="flex gap-2 flex-wrap">
          {FILTERS.map(s => {
            const count = s === "All" ? bookings.length : bookings.filter(b => b.status === s).length;
            return (
              <button
                key={s}
                onClick={() => setFilter(s)}
                className={`px-4 py-2 rounded-xl text-sm font-medium border transition-all ${
                  filter === s ? "bg-primary text-white border-primary" : "bg-white dark:bg-slate-800 dark:text-slate-300 text-slate-600 border-border hover:bg-slate-50 dark:hover:bg-slate-700"
                }`}
              >
                {s} <span className={`ml-1 text-xs ${filter === s ? "text-blue-200" : "text-slate-400"}`}>{count}</span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="bg-white dark:bg-slate-800 rounded-2xl border border-border shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[900px]">
            <thead>
              <tr className="border-b border-border bg-slate-50 dark:bg-slate-700/50 text-xs text-slate-500 uppercase tracking-wider">
                <th className="px-5 py-3.5 text-left font-medium">Booking ID</th>
                <th className="px-5 py-3.5 text-left font-medium">Customer</th>
                <th className="px-5 py-3.5 text-left font-medium">Service</th>
                <th className="px-5 py-3.5 text-left font-medium">Date & Slot</th>
                <th className="px-5 py-3.5 text-left font-medium">Assigned To</th>
                <th className="px-5 py-3.5 text-left font-medium">Status</th>
                <th className="px-5 py-3.5 text-left font-medium">Amount</th>
                <th className="px-5 py-3.5 text-left font-medium">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filtered.map(b => {
                const customer = getCustomer(b.customerId);
                const pro = getPro(b.assignedProId);
                const sc = statusConfig[b.status];
                const StatusIcon = sc.icon;
                return (
                  <tr key={b.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors">
                    <td className="px-5 py-4">
                      <span className="font-mono text-xs font-semibold text-slate-700 dark:text-slate-300">{b.id}</span>
                    </td>
                    <td className="px-5 py-4">
                      <p className="text-sm font-medium text-slate-900 dark:text-slate-100">{customer?.name}</p>
                      <p className="text-xs text-slate-500">{customer?.phone}</p>
                    </td>
                    <td className="px-5 py-4">
                      <p className="text-sm text-slate-900 dark:text-slate-100">{b.service}</p>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${tradeColors[b.category] || "bg-slate-100 text-slate-600"}`}>{b.category}</span>
                    </td>
                    <td className="px-5 py-4">
                      <p className="text-sm text-slate-700 dark:text-slate-300">{b.date}</p>
                      <p className="text-xs text-slate-500">{b.slot}</p>
                    </td>
                    <td className="px-5 py-4">
                      {pro ? (
                        <div className="flex items-center gap-2">
                          <div className="size-6 rounded-full bg-blue-100 flex items-center justify-center text-primary text-[10px] font-bold">{pro.name[0]}</div>
                          <div>
                            <p className="text-xs font-medium dark:text-slate-200">{pro.name}</p>
                            <p className="text-xs text-slate-500">{pro.trade}</p>
                          </div>
                        </div>
                      ) : (
                        <span className="text-xs text-slate-400 italic">Not assigned</span>
                      )}
                    </td>
                    <td className="px-5 py-4">
                      <span className={`inline-flex items-center gap-1 text-xs font-medium px-2.5 py-1 rounded-full border ${sc.bg} ${sc.color}`}>
                        <StatusIcon size={11} /> {b.status}
                      </span>
                    </td>
                    <td className="px-5 py-4">
                      <span className="text-sm font-semibold text-slate-900 dark:text-slate-100">₹{b.amount}</span>
                    </td>
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-2">
                        <button onClick={() => onView(b)} className="text-slate-400 hover:text-primary transition-colors"><Eye size={15} /></button>
                        {(b.status === "Pending" || b.status === "Assigned") && (
                          <button onClick={() => onAssign(b)} className="text-xs text-primary border border-primary px-2 py-0.5 rounded-lg hover:bg-primary hover:text-white transition-colors">
                            {b.status === "Pending" ? "Assign" : "Reassign"}
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && (
          <div className="py-16 text-center text-slate-400 text-sm">No bookings match this filter.</div>
        )}
      </div>
    </div>
  );
}
