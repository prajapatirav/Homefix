import { useState } from "react";
import { BriefcaseBusiness, UserCheck, RefreshCw, Edit2, Trash2, Plus } from "lucide-react";
import { formatRelative } from "../../lib/utils";
import type { ActivityLog } from "../../lib/types";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const TYPE_CONFIG: Record<ActivityLog["type"], { icon: any; color: string; bg: string }> = {
  create: { icon: Plus, color: "text-emerald-600", bg: "bg-emerald-100" },
  assign: { icon: UserCheck, color: "text-blue-600", bg: "bg-blue-100" },
  status: { icon: RefreshCw, color: "text-violet-600", bg: "bg-violet-100" },
  edit: { icon: Edit2, color: "text-amber-600", bg: "bg-amber-100" },
  delete: { icon: Trash2, color: "text-red-500", bg: "bg-red-100" },
};

const FILTERS = ["All", "Bookings", "Professionals"] as const;

export function ActivityLogSection({ logs }: { logs: ActivityLog[] }) {
  const [filter, setFilter] = useState<typeof FILTERS[number]>("All");

  const filtered = filter === "All"
    ? logs
    : filter === "Bookings"
    ? logs.filter(l => l.bookingId)
    : logs.filter(l => l.proId && !l.bookingId);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <h2 className="font-semibold text-slate-900 dark:text-slate-100">Activity Log</h2>
        <div className="flex gap-2">
          {FILTERS.map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-xl text-sm border transition-all ${
                filter === f ? "bg-primary text-white border-primary" : "bg-white dark:bg-slate-800 dark:text-slate-300 border-border hover:bg-slate-50 dark:hover:bg-slate-700"
              }`}
            >
              {f}
            </button>
          ))}
        </div>
        <span className="text-xs text-slate-400 ml-auto">{filtered.length} entries</span>
      </div>

      <div className="bg-white dark:bg-slate-800 rounded-2xl border border-border shadow-sm overflow-hidden">
        <div className="divide-y divide-border">
          {filtered.slice(0, 50).map(log => {
            const cfg = TYPE_CONFIG[log.type];
            const Icon = cfg.icon;
            return (
              <div key={log.id} className="flex items-start gap-4 px-5 py-4 hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors">
                <div className={`${cfg.bg} size-8 rounded-xl flex items-center justify-center flex-shrink-0 mt-0.5`}>
                  <Icon size={14} className={cfg.color} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-slate-900 dark:text-slate-100">{log.message}</p>
                  <div className="flex items-center gap-3 mt-1">
                    {log.bookingId && (
                      <span className="text-xs font-mono text-slate-500">{log.bookingId}</span>
                    )}
                    {log.proId && (
                      <span className="flex items-center gap-1 text-xs text-slate-400">
                        <UserCheck size={10} /> Pro
                      </span>
                    )}
                  </div>
                </div>
                <time className="text-xs text-slate-400 flex-shrink-0 mt-0.5">{formatRelative(log.timestamp)}</time>
              </div>
            );
          })}
          {filtered.length === 0 && (
            <div className="py-16 text-center text-slate-400 text-sm">No activity entries yet.</div>
          )}
        </div>
      </div>
    </div>
  );
}
