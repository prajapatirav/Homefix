import { LayoutDashboard, BriefcaseBusiness, UserCheck, TrendingUp, AlertCircle, ArrowUpRight, Eye, Clock } from "lucide-react";
import { BookingsByDayChart } from "../charts/BookingsByDayChart";
import { CategoryPieChart } from "../charts/CategoryPieChart";
import { RevenueLineChart } from "../charts/RevenueLineChart";
import type { Booking, Professional, Customer, AdminSection } from "../../lib/types";
import { statusConfig, TODAY } from "../../lib/utils";

type Props = {
  bookings: Booking[];
  professionals: Professional[];
  customers: Customer[];
  getCustomer: (id: string) => Customer | undefined;
  getPro: (id: string | null) => Professional | undefined;
  onAssign: (b: Booking) => void;
  onViewBooking: (b: Booking) => void;
  setSection: (s: AdminSection) => void;
};

export function DashboardSection({ bookings, professionals, customers, getCustomer, getPro, onAssign, onViewBooking, setSection }: Props) {
  const pending = bookings.filter(b => b.status === "Pending").length;
  const inProgress = bookings.filter(b => b.status === "In Progress").length;
  const activePros = professionals.filter(p => p.status === "Active").length;
  const revenue = bookings.filter(b => b.status === "Completed").reduce((a, b) => a + b.amount, 0);
  const todayBookings = bookings.filter(b => b.date === TODAY);

  const stats = [
    { label: "Today's Bookings", value: todayBookings.length, sub: `${pending} unassigned`, icon: BriefcaseBusiness, color: "bg-blue-600", trend: "+3 vs yesterday" },
    { label: "Pending Assignment", value: pending, sub: "Needs action now", icon: AlertCircle, color: "bg-amber-500", trend: "" },
    { label: "Active Professionals", value: activePros, sub: `${professionals.length} total`, icon: UserCheck, color: "bg-emerald-600", trend: "" },
    { label: "Monthly Revenue", value: `₹${(revenue + 45000).toLocaleString()}`, sub: "Completed bookings", icon: TrendingUp, color: "bg-violet-600", trend: "+12% vs last month" },
  ];

  const recent = [...bookings]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 6);

  const todaySorted = [...todayBookings].sort((a, b) => a.slot.localeCompare(b.slot));

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
        {stats.map(s => {
          const Icon = s.icon;
          return (
            <div key={s.label} className="bg-white dark:bg-slate-800 rounded-2xl p-5 border border-border shadow-sm">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm text-slate-500">{s.label}</p>
                  <p className="text-2xl font-bold text-slate-900 dark:text-slate-100 mt-1">{s.value}</p>
                  <p className="text-xs text-slate-400 mt-1">{s.sub}</p>
                </div>
                <div className={`${s.color} size-10 rounded-xl flex items-center justify-center`}>
                  <Icon size={18} className="text-white" />
                </div>
              </div>
              {s.trend && (
                <div className="mt-3 flex items-center gap-1 text-xs text-emerald-600">
                  <ArrowUpRight size={12} /> {s.trend}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        <div className="xl:col-span-2">
          <BookingsByDayChart bookings={bookings} />
        </div>
        <CategoryPieChart bookings={bookings} />
      </div>

      {/* Revenue line */}
      <RevenueLineChart bookings={bookings} />

      {/* Today's schedule + Available pros */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Today's Schedule */}
        <div className="xl:col-span-2 bg-white dark:bg-slate-800 rounded-2xl border border-border shadow-sm overflow-hidden">
          <div className="flex items-center justify-between px-5 py-4 border-b border-border">
            <div className="flex items-center gap-2">
              <Clock size={16} className="text-primary" />
              <h2 className="font-semibold text-slate-900 dark:text-slate-100">Today's Schedule</h2>
            </div>
            <button onClick={() => setSection("bookings")} className="text-xs text-primary hover:underline">View all</button>
          </div>
          <div className="divide-y divide-border">
            {todaySorted.length === 0 ? (
              <p className="py-8 text-center text-slate-400 text-sm">No bookings scheduled for today</p>
            ) : todaySorted.map(b => {
              const sc = statusConfig[b.status];
              const StatusIcon = sc.icon;
              const customer = getCustomer(b.customerId);
              const pro = getPro(b.assignedProId);
              return (
                <div key={b.id} className="flex items-center gap-4 px-5 py-3.5 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors">
                  <div className="w-16 text-center flex-shrink-0">
                    <p className="text-xs font-bold text-slate-700 dark:text-slate-300">{b.slot}</p>
                  </div>
                  <div className={`w-1 self-stretch rounded-full ${b.status === "In Progress" ? "bg-violet-500 animate-pulse" : sc.color.replace("text-", "bg-")}`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-slate-900 dark:text-slate-100 truncate">{b.service}</p>
                    <p className="text-xs text-slate-500">{customer?.name} · {pro ? pro.name : "Unassigned"}</p>
                  </div>
                  <span className={`shrink-0 flex items-center gap-1 text-xs px-2.5 py-1 rounded-full border ${sc.bg} ${sc.color}`}>
                    <StatusIcon size={10} /> {b.status}
                  </span>
                  {b.status === "Pending" && (
                    <button onClick={() => onAssign(b)} className="shrink-0 text-xs bg-primary text-white px-2.5 py-1 rounded-lg hover:bg-blue-700">Assign</button>
                  )}
                  <button onClick={() => onViewBooking(b)} className="shrink-0 text-slate-400 hover:text-slate-600"><Eye size={14} /></button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Available Professionals */}
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-800 rounded-2xl border border-border shadow-sm p-5">
            <h3 className="font-semibold text-slate-900 dark:text-slate-100 mb-4">Available Now</h3>
            <div className="space-y-3">
              {professionals.filter(p => p.status === "Active").map(p => (
                <div key={p.id} className="flex items-center gap-3">
                  <div className="size-8 rounded-full bg-gradient-to-br from-blue-100 to-blue-200 flex items-center justify-center text-primary text-xs font-bold">
                    {p.name.split(" ").map(n => n[0]).join("")}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium dark:text-slate-100 truncate">{p.name}</p>
                    <p className="text-xs text-slate-500">{p.trade}</p>
                  </div>
                  <span className="text-xs text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">Free</span>
                </div>
              ))}
              {professionals.filter(p => p.status === "Busy").map(p => (
                <div key={p.id} className="flex items-center gap-3 opacity-60">
                  <div className="size-8 rounded-full bg-amber-100 flex items-center justify-center text-amber-700 text-xs font-bold">
                    {p.name.split(" ").map(n => n[0]).join("")}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium dark:text-slate-100 truncate">{p.name}</p>
                    <p className="text-xs text-slate-500">{p.trade}</p>
                  </div>
                  <span className="text-xs text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full">Busy</span>
                </div>
              ))}
            </div>
          </div>

          {/* Recent bookings mini feed */}
          <div className="bg-white dark:bg-slate-800 rounded-2xl border border-border shadow-sm overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-border">
              <h3 className="font-semibold text-slate-900 dark:text-slate-100 text-sm">Recent Bookings</h3>
              <button onClick={() => setSection("bookings")} className="text-xs text-primary hover:underline">All</button>
            </div>
            <div className="divide-y divide-border">
              {recent.map(b => {
                const customer = getCustomer(b.customerId);
                const sc = statusConfig[b.status];
                const StatusIcon = sc.icon;
                return (
                  <div key={b.id} className="flex items-center gap-3 px-5 py-3 hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors">
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-slate-900 dark:text-slate-100 truncate">{b.service}</p>
                      <p className="text-xs text-slate-500">{customer?.name}</p>
                    </div>
                    <span className={`shrink-0 text-xs font-medium flex items-center gap-1 ${sc.color}`}>
                      <StatusIcon size={10} /> {b.status}
                    </span>
                    {b.status === "Pending" && (
                      <button onClick={() => onAssign(b)} className="shrink-0 text-xs text-primary border border-primary px-2 py-0.5 rounded-lg hover:bg-primary hover:text-white transition-colors">Assign</button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
