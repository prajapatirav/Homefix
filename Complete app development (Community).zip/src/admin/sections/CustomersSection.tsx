import type { Booking, Customer, Professional } from "../../lib/types";

type Props = {
  customers: Customer[];
  bookings: Booking[];
  getPro: (id: string | null) => Professional | undefined;
};

export function CustomersSection({ customers, bookings, getPro }: Props) {
  return (
    <div className="bg-white dark:bg-slate-800 rounded-2xl border border-border shadow-sm overflow-hidden">
      <div className="px-5 py-4 border-b border-border">
        <h2 className="font-semibold text-slate-900 dark:text-slate-100">
          All Customers <span className="text-slate-400 font-normal text-sm">({customers.length})</span>
        </h2>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[700px]">
          <thead>
            <tr className="border-b border-border bg-slate-50 dark:bg-slate-700/50 text-xs text-slate-500 uppercase tracking-wider">
              <th className="px-5 py-3.5 text-left font-medium">Customer</th>
              <th className="px-5 py-3.5 text-left font-medium">Contact</th>
              <th className="px-5 py-3.5 text-left font-medium">Address</th>
              <th className="px-5 py-3.5 text-left font-medium">Bookings</th>
              <th className="px-5 py-3.5 text-left font-medium">Total Spent</th>
              <th className="px-5 py-3.5 text-left font-medium">Last Service</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {customers.map(c => {
              const cBookings = bookings.filter(b => b.customerId === c.id);
              const last = [...cBookings].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())[0];
              const totalSpent = cBookings.filter(b => b.status === "Completed").reduce((s, b) => s + b.amount, 0) || c.totalSpent;
              return (
                <tr key={c.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/30 transition-colors">
                  <td className="px-5 py-4">
                    <div className="flex items-center gap-3">
                      <div className="size-9 rounded-full bg-gradient-to-br from-blue-100 to-slate-200 flex items-center justify-center text-primary text-sm font-bold">
                        {c.name.split(" ").map(n => n[0]).join("")}
                      </div>
                      <div>
                        <p className="text-sm font-medium dark:text-slate-100">{c.name}</p>
                        <p className="text-xs text-slate-400">{c.id}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-5 py-4">
                    <p className="text-sm text-slate-700 dark:text-slate-300">{c.phone}</p>
                    <p className="text-xs text-slate-500">{c.email}</p>
                  </td>
                  <td className="px-5 py-4">
                    <p className="text-xs text-slate-600 dark:text-slate-400 max-w-[180px] truncate">{c.address}</p>
                  </td>
                  <td className="px-5 py-4">
                    <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">{cBookings.length}</p>
                    <p className="text-xs text-slate-400">{cBookings.filter(b => b.status === "Pending").length} pending</p>
                  </td>
                  <td className="px-5 py-4">
                    <p className="text-sm font-semibold text-slate-900 dark:text-slate-100">₹{totalSpent.toLocaleString()}</p>
                  </td>
                  <td className="px-5 py-4">
                    {last ? (
                      <div>
                        <p className="text-xs font-medium text-slate-700 dark:text-slate-300 truncate max-w-[140px]">{last.service}</p>
                        <p className="text-xs text-slate-400">{last.date}</p>
                      </div>
                    ) : <span className="text-xs text-slate-400">—</span>}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
