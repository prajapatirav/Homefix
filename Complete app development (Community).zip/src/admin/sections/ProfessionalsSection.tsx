import { useMemo, useState } from "react";
import { Plus, BadgeCheck, Phone, MapPin, Star, Edit2, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { Booking, Professional, ActivityLog } from "../../lib/types";
import { tradeColors } from "../../lib/utils";

type Props = {
  professionals: Professional[];
  setProfessionals: (p: Professional[]) => void;
  bookings: Booking[];
  onEdit: (p: Professional | "new") => void;
  addLog: (entry: Omit<ActivityLog, "id" | "timestamp">) => void;
};

const STATUS_FILTERS = ["All", "Active", "Busy", "Offline"] as const;

export function ProfessionalsSection({ professionals, setProfessionals, bookings, onEdit, addLog }: Props) {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<"All" | Professional["status"]>("All");

  const filtered = useMemo(() => {
    let result = statusFilter === "All" ? professionals : professionals.filter(p => p.status === statusFilter);
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(p =>
        p.name.toLowerCase().includes(q) ||
        p.trade.toLowerCase().includes(q) ||
        p.location.toLowerCase().includes(q)
      );
    }
    return result;
  }, [professionals, search, statusFilter]);

  function getEarnings(proId: string) {
    return bookings
      .filter(b => b.assignedProId === proId && b.status === "Completed")
      .reduce((sum, b) => sum + b.amount * 0.7, 0);
  }

  function getActiveJobs(proId: string) {
    return bookings.filter(b => b.assignedProId === proId && (b.status === "Assigned" || b.status === "In Progress")).length;
  }

  function toggleStatus(p: Professional) {
    const next: Professional["status"] = p.status === "Active" ? "Offline" : "Active";
    setProfessionals(professionals.map(x => x.id === p.id ? { ...x, status: next } : x));
    toast.success(`${p.name} is now ${next}`);
  }

  function deletePro(p: Professional) {
    if (!window.confirm(`Remove ${p.name}? This cannot be undone.`)) return;
    setProfessionals(professionals.filter(x => x.id !== p.id));
    addLog({ type: "delete", message: `Professional ${p.name} removed`, proId: p.id });
    toast.error(`${p.name} removed`);
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
        <div className="flex gap-3 flex-1 flex-wrap">
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search name, trade, area…"
            className="rounded-xl border border-border px-4 py-2.5 text-sm bg-white dark:bg-slate-800 dark:text-slate-100 outline-none focus:ring-2 focus:ring-ring w-full sm:w-56"
          />
          <div className="flex gap-2">
            {STATUS_FILTERS.map(s => (
              <button
                key={s}
                onClick={() => setStatusFilter(s as any)}
                className={`px-3 py-2 rounded-xl text-sm border transition-all ${
                  statusFilter === s ? "bg-primary text-white border-primary" : "bg-white dark:bg-slate-800 dark:text-slate-300 border-border hover:bg-slate-50 dark:hover:bg-slate-700"
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>
        <button
          onClick={() => onEdit("new")}
          className="flex items-center gap-2 bg-primary text-white px-4 py-2.5 rounded-xl text-sm font-medium hover:bg-blue-700 transition-colors shrink-0"
        >
          <Plus size={16} /> Add Professional
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map(p => {
          const earnings = getEarnings(p.id);
          const activeJobs = getActiveJobs(p.id);
          const platformShare = earnings / 0.7;

          return (
            <div key={p.id} className="bg-white dark:bg-slate-800 rounded-2xl border border-border shadow-sm p-5 flex flex-col gap-4">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="size-12 rounded-2xl bg-gradient-to-br from-blue-100 to-blue-200 flex items-center justify-center text-primary font-bold text-lg">
                    {p.name.split(" ").map(n => n[0]).join("")}
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h3 className="text-sm font-semibold dark:text-slate-100">{p.name}</h3>
                      {p.verified && <BadgeCheck size={14} className="text-blue-500" />}
                    </div>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${tradeColors[p.trade] || "bg-slate-100 text-slate-600"}`}>{p.trade}</span>
                  </div>
                </div>
                <button
                  onClick={() => toggleStatus(p)}
                  className={`text-xs px-2.5 py-1 rounded-full font-medium border transition-all ${
                    p.status === "Active" ? "bg-emerald-50 text-emerald-600 border-emerald-200" :
                    p.status === "Busy" ? "bg-amber-50 text-amber-600 border-amber-200" :
                    "bg-slate-100 text-slate-500 border-slate-200"
                  }`}
                >
                  {p.status}
                </button>
              </div>

              <div className="space-y-1.5 text-xs text-slate-500">
                <div className="flex items-center gap-2"><Phone size={12}/> {p.phone}</div>
                <div className="flex items-center gap-2"><MapPin size={12}/> {p.location}</div>
                <div className="flex items-center gap-2"><Star size={12} className="fill-amber-400 text-amber-400"/> {p.rating} · {p.completedJobs} jobs · {p.experience} yrs exp</div>
              </div>

              {/* Earnings panel */}
              {earnings > 0 && (
                <div className="rounded-xl bg-slate-50 dark:bg-slate-700/50 p-3">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-xs text-slate-500">Earnings (70% payout)</p>
                    <p className="text-sm font-bold text-emerald-600">₹{Math.round(earnings).toLocaleString()}</p>
                  </div>
                  <div className="h-1.5 bg-slate-200 dark:bg-slate-600 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-emerald-500 rounded-full"
                      style={{ width: `${Math.min(100, (earnings / (platformShare || 1)) * 70)}%` }}
                    />
                  </div>
                  <p className="text-xs text-slate-400 mt-1">Platform share: ₹{Math.round(platformShare * 0.3).toLocaleString()}</p>
                </div>
              )}

              <div className="flex items-center gap-2 pt-1 border-t border-border">
                <div className="flex-1 text-xs text-slate-500">
                  {activeJobs > 0 ? (
                    <span className="text-blue-600 font-medium">{activeJobs} active booking{activeJobs > 1 ? "s" : ""}</span>
                  ) : (
                    <span>Available now</span>
                  )}
                </div>
                <button onClick={() => onEdit(p)} className="text-xs text-primary hover:underline flex items-center gap-1">
                  <Edit2 size={11} /> Edit
                </button>
                <button onClick={() => deletePro(p)} className="text-xs text-red-500 hover:underline flex items-center gap-1">
                  <Trash2 size={11} /> Remove
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <div className="py-16 text-center text-slate-400 text-sm">No professionals match your search.</div>
      )}
    </div>
  );
}
