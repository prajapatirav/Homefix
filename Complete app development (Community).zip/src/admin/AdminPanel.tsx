import { useEffect, useState } from "react";
import { useTheme } from "next-themes";
import {
  Bell, Home, LayoutDashboard, BriefcaseBusiness, UserCheck, Users,
  Menu, User, Activity, Sun, Moon, Search,
} from "lucide-react";
import { toast } from "sonner";
import type { Booking, Professional, Customer, AdminSection, BookingStatus, ActivityLog } from "../lib/types";
import { DashboardSection } from "./sections/DashboardSection";
import { BookingsSection } from "./sections/BookingsSection";
import { ProfessionalsSection } from "./sections/ProfessionalsSection";
import { CustomersSection } from "./sections/CustomersSection";
import { ActivityLogSection } from "./sections/ActivityLogSection";
import { AssignModal } from "./modals/AssignModal";
import { ViewBookingModal } from "./modals/ViewBookingModal";
import { ProModal } from "./modals/ProModal";
import { CommandPalette } from "./CommandPalette";

type Props = {
  bookings: Booking[];
  updateBooking: (id: string, patch: Partial<Booking>) => void;
  professionals: Professional[];
  setProfessionals: (p: Professional[]) => void;
  addProfessional: (p: Professional) => void;
  updateProfessional: (id: string, patch: Partial<Professional>) => void;
  removeProfessional: (id: string) => void;
  customers: Customer[];
  logs: ActivityLog[];
  addLog: (entry: Omit<ActivityLog, "id" | "timestamp">) => void;
};

export function AdminPanel({
  bookings, updateBooking,
  professionals, setProfessionals, addProfessional, updateProfessional, removeProfessional,
  customers, logs, addLog,
}: Props) {
  const { theme, setTheme } = useTheme();
  const [section, setSection] = useState<AdminSection>("dashboard");
  const [assignModal, setAssignModal] = useState<Booking | null>(null);
  const [viewModal, setViewModal] = useState<Booking | null>(null);
  const [proModal, setProModal] = useState<Professional | "new" | null>(null);
  const [palette, setPalette] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  // Cmd+K handler
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setPalette(p => !p);
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const pending = bookings.filter(b => b.status === "Pending").length;

  function getCustomer(id: string) { return customers.find(c => c.id === id); }
  function getPro(id: string | null) { return professionals.find(p => p.id === id); }

  function handleAssign(bookingId: string, proId: string, proName: string) {
    updateBooking(bookingId, { assignedProId: proId, status: "Assigned" });
  }

  function handleStatusChange(bookingId: string, status: BookingStatus) {
    updateBooking(bookingId, { status });
  }

  function handleSavePro(p: Professional) {
    if (proModal === "new") {
      addProfessional(p);
    } else {
      updateProfessional(p.id, p);
    }
  }

  function handleDeletePro(id: string) {
    removeProfessional(id);
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const navItems: [AdminSection, any, string][] = [
    ["dashboard", LayoutDashboard, "Dashboard"],
    ["bookings", BriefcaseBusiness, "Bookings"],
    ["professionals", UserCheck, "Professionals"],
    ["customers", Users, "Customers"],
    ["activity", Activity, "Activity Log"],
  ];

  const sectionTitles: Record<AdminSection, string> = {
    dashboard: "Dashboard",
    bookings: "Bookings",
    professionals: "Professionals",
    customers: "Customers",
    activity: "Activity Log",
  };

  return (
    <div className="flex h-screen bg-[#f0f4f8] dark:bg-slate-900 font-['Inter',sans-serif] overflow-hidden">
      {/* Sidebar */}
      <aside className={`${sidebarOpen ? "w-60" : "w-16"} transition-all duration-200 flex-shrink-0 bg-slate-950 flex flex-col`}>
        <div className="flex items-center gap-3 px-4 py-5 border-b border-white/10">
          <div className="size-8 rounded-xl bg-primary flex items-center justify-center flex-shrink-0">
            <Home size={16} className="text-white" />
          </div>
          {sidebarOpen && <span className="font-['Roboto_Slab'] text-white text-lg leading-none">HomeFix</span>}
        </div>
        {sidebarOpen && (
          <div className="px-4 py-3 border-b border-white/10">
            <p className="text-xs text-slate-400 uppercase tracking-widest">Admin Panel</p>
          </div>
        )}
        <nav className="flex-1 py-4 space-y-1 px-2">
          {navItems.map(([s, Icon, label]) => (
            <button
              key={s}
              onClick={() => setSection(s)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all ${
                section === s ? "bg-primary text-white" : "text-slate-400 hover:text-white hover:bg-white/5"
              }`}
            >
              <Icon size={18} className="flex-shrink-0" />
              {sidebarOpen && <span>{label}</span>}
              {sidebarOpen && s === "bookings" && pending > 0 && (
                <span className="ml-auto bg-amber-400 text-slate-900 text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">{pending}</span>
              )}
            </button>
          ))}
        </nav>
        <div className="p-3 border-t border-white/10">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/5 text-sm"
          >
            <Menu size={18} />
            {sidebarOpen && <span>Collapse</span>}
          </button>
        </div>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white dark:bg-slate-800 border-b border-border px-6 py-4 flex items-center gap-4">
          <div>
            <h1 className="font-['Roboto_Slab'] text-xl text-slate-900 dark:text-slate-100">{sectionTitles[section]}</h1>
            <p className="text-xs text-slate-500 mt-0.5">Monday, 23 June 2026</p>
          </div>
          <div className="ml-auto flex items-center gap-3">
            {/* Cmd+K hint */}
            <button
              onClick={() => setPalette(true)}
              className="hidden sm:flex items-center gap-2 px-3 py-2 rounded-xl border border-border bg-slate-50 dark:bg-slate-700 text-sm text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-600"
            >
              <Search size={14} />
              <span>Search</span>
              <kbd className="ml-2 text-xs border border-border rounded px-1.5 py-0.5">⌘K</kbd>
            </button>

            {/* Dark mode toggle */}
            <button
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              className="grid size-9 place-items-center rounded-xl border border-border bg-white dark:bg-slate-700 hover:bg-slate-50 dark:hover:bg-slate-600 text-slate-600 dark:text-slate-300"
            >
              {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
            </button>

            <button className="relative grid size-9 place-items-center rounded-xl border border-border bg-white dark:bg-slate-700 hover:bg-slate-50 dark:hover:bg-slate-600">
              <Bell size={16} className="text-slate-600 dark:text-slate-300" />
              {pending > 0 && <span className="absolute -top-1 -right-1 size-4 bg-red-500 rounded-full text-white text-[10px] flex items-center justify-center">{pending}</span>}
            </button>

            <div className="flex items-center gap-2 pl-3 border-l border-border">
              <div className="size-8 rounded-full bg-primary flex items-center justify-center">
                <User size={15} className="text-white" />
              </div>
              <div className="hidden sm:block">
                <p className="text-sm font-semibold dark:text-slate-100">Admin</p>
                <p className="text-xs text-slate-500">admin@homefix.in</p>
              </div>
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-y-auto p-6">
          {section === "dashboard" && (
            <DashboardSection
              bookings={bookings}
              professionals={professionals}
              customers={customers}
              getCustomer={getCustomer}
              getPro={getPro}
              onAssign={setAssignModal}
              onViewBooking={setViewModal}
              setSection={setSection}
            />
          )}
          {section === "bookings" && (
            <BookingsSection
              bookings={bookings}
              getCustomer={getCustomer}
              getPro={getPro}
              onAssign={setAssignModal}
              onView={setViewModal}
              onStatusChange={handleStatusChange}
            />
          )}
          {section === "professionals" && (
            <ProfessionalsSection
              professionals={professionals}
              setProfessionals={setProfessionals}
              bookings={bookings}
              onEdit={setProModal}
              addLog={addLog}
            />
          )}
          {section === "customers" && (
            <CustomersSection customers={customers} bookings={bookings} getPro={getPro} />
          )}
          {section === "activity" && (
            <ActivityLogSection logs={logs} />
          )}
        </main>
      </div>

      {/* Modals */}
      <AssignModal
        booking={assignModal}
        professionals={professionals}
        getCustomer={getCustomer}
        onAssign={handleAssign}
        onClose={() => setAssignModal(null)}
        addLog={addLog}
      />

      <ViewBookingModal
        booking={viewModal}
        getCustomer={getCustomer}
        getPro={getPro}
        onAssign={() => { if (viewModal) { setAssignModal(viewModal); setViewModal(null); } }}
        onStatusChange={handleStatusChange}
        onClose={() => setViewModal(null)}
        addLog={addLog}
      />

      <ProModal
        pro={proModal === "new" ? null : proModal as Professional | null}
        isOpen={proModal !== null}
        onSave={handleSavePro}
        onClose={() => setProModal(null)}
        addLog={addLog}
      />

      <CommandPalette
        open={palette}
        onClose={() => setPalette(false)}
        setSection={setSection}
        onAddPro={() => { setSection("professionals"); setProModal("new"); }}
        recentBookings={bookings.slice(0, 5)}
      />
    </div>
  );
}
