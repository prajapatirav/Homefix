import * as Dialog from "@radix-ui/react-dialog";
import { motion } from "motion/react";
import { X, Check } from "lucide-react";
import { toast } from "sonner";
import type { Booking, Professional, Customer, BookingStatus, ActivityLog } from "../../lib/types";
import { statusConfig, tradeColors } from "../../lib/utils";

type Props = {
  booking: Booking | null;
  getCustomer: (id: string) => Customer | undefined;
  getPro: (id: string | null) => Professional | undefined;
  onAssign: () => void;
  onStatusChange: (id: string, status: BookingStatus) => void;
  onClose: () => void;
  addLog: (entry: Omit<ActivityLog, "id" | "timestamp">) => void;
};

const ALL_STATUSES: BookingStatus[] = ["Pending", "Assigned", "In Progress", "Completed", "Cancelled"];

export function ViewBookingModal({ booking, getCustomer, getPro, onAssign, onStatusChange, onClose, addLog }: Props) {
  if (!booking) return null;
  const customer = getCustomer(booking.customerId);
  const pro = getPro(booking.assignedProId);

  function handleStatus(s: BookingStatus) {
    if (s === booking!.status) return;
    onStatusChange(booking!.id, s);
    addLog({ type: "status", message: `Booking ${booking!.id} status changed to ${s}`, bookingId: booking!.id });
    toast.success(`Status → ${s}`);
    onClose();
  }

  return (
    <Dialog.Root open={!!booking} onOpenChange={open => !open && onClose()}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50" />
        <Dialog.Content asChild>
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50 bg-white dark:bg-slate-800 rounded-2xl shadow-xl w-full max-w-md overflow-hidden"
          >
            <div className="flex items-center justify-between px-6 py-4 border-b border-border">
              <div>
                <Dialog.Title className="font-semibold text-slate-900 dark:text-slate-100">Booking Details</Dialog.Title>
                <p className="text-xs font-mono text-slate-500 mt-0.5">{booking.id}</p>
              </div>
              <Dialog.Close asChild>
                <button className="text-slate-400 hover:text-slate-600"><X size={20} /></button>
              </Dialog.Close>
            </div>

            <div className="px-6 py-5 space-y-4 max-h-[70vh] overflow-y-auto">
              <div>
                <p className="text-xs text-slate-500 mb-1">Service</p>
                <p className="font-medium text-slate-900 dark:text-slate-100">{booking.service}</p>
                <span className={`text-xs px-2 py-0.5 rounded-full ${tradeColors[booking.category] || "bg-slate-100 text-slate-600"}`}>{booking.category}</span>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-3 border-t border-border">
                <div>
                  <p className="text-xs text-slate-500 mb-1">Date</p>
                  <p className="text-sm font-medium dark:text-slate-100">{booking.date}</p>
                </div>
                <div>
                  <p className="text-xs text-slate-500 mb-1">Time Slot</p>
                  <p className="text-sm font-medium dark:text-slate-100">{booking.slot}</p>
                </div>
              </div>

              <div className="pt-3 border-t border-border">
                <p className="text-xs text-slate-500 mb-2">Customer</p>
                {customer && (
                  <div className="flex items-center gap-3">
                    <div className="size-9 rounded-full bg-blue-100 flex items-center justify-center text-primary font-bold text-sm">{customer.name[0]}</div>
                    <div>
                      <p className="text-sm font-medium dark:text-slate-100">{customer.name}</p>
                      <p className="text-xs text-slate-500">{customer.phone}</p>
                      <p className="text-xs text-slate-500">{booking.address}</p>
                    </div>
                  </div>
                )}
              </div>

              <div className="pt-3 border-t border-border">
                <p className="text-xs text-slate-500 mb-2">Assigned Professional</p>
                {pro ? (
                  <div className="flex items-center gap-3">
                    <div className="size-9 rounded-full bg-blue-100 flex items-center justify-center text-primary font-bold text-sm">
                      {pro.name.split(" ").map(n => n[0]).join("")}
                    </div>
                    <div>
                      <p className="text-sm font-medium dark:text-slate-100">{pro.name}</p>
                      <p className="text-xs text-slate-500">{pro.trade} · {pro.phone}</p>
                    </div>
                    <button onClick={onAssign} className="ml-auto text-xs text-primary hover:underline">Change</button>
                  </div>
                ) : (
                  <div className="flex items-center justify-between">
                    <p className="text-sm text-slate-400 italic">Not yet assigned</p>
                    <button onClick={onAssign} className="text-xs bg-primary text-white px-3 py-1.5 rounded-lg hover:bg-blue-700">Assign Now</button>
                  </div>
                )}
              </div>

              {booking.notes && (
                <div className="pt-3 border-t border-border">
                  <p className="text-xs text-slate-500 mb-1">Customer Notes</p>
                  <p className="text-sm text-slate-700 dark:text-slate-300 italic">"{booking.notes}"</p>
                </div>
              )}

              <div className="pt-3 border-t border-border">
                <p className="text-xs text-slate-500 mb-2">Update Status</p>
                <div className="grid grid-cols-2 gap-2">
                  {ALL_STATUSES.map(s => {
                    const cfg = statusConfig[s];
                    const SIcon = cfg.icon;
                    return (
                      <button
                        key={s}
                        onClick={() => handleStatus(s)}
                        className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs border transition-all ${
                          booking.status === s
                            ? `${cfg.bg} ${cfg.color} border-current`
                            : "border-border hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300"
                        }`}
                      >
                        <SIcon size={12} /> {s}
                        {booking.status === s && <Check size={11} className="ml-auto" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="pt-3 border-t border-border flex justify-between items-center">
                <p className="text-xs text-slate-500">Total Amount</p>
                <p className="text-xl font-bold text-slate-900 dark:text-slate-100">₹{booking.amount}</p>
              </div>
            </div>
          </motion.div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
