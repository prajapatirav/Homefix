import * as Dialog from "@radix-ui/react-dialog";
import { useState } from "react";
import { motion } from "motion/react";
import { X, Save } from "lucide-react";
import { toast } from "sonner";
import type { Professional, ActivityLog } from "../../lib/types";
import { generateProId } from "../../lib/utils";

const TRADES = ["Plumber", "Electrician", "Carpenter", "AC Technician", "Painter", "Cleaner", "Pest Control", "Appliance Repair", "RO Technician"];

type Props = {
  pro: Professional | null;
  isOpen: boolean;
  onSave: (p: Professional) => void;
  onClose: () => void;
  addLog: (entry: Omit<ActivityLog, "id" | "timestamp">) => void;
};

export function ProModal({ pro, isOpen, onSave, onClose, addLog }: Props) {
  const [form, setForm] = useState<Professional>(
    pro ?? {
      id: generateProId(),
      name: "",
      trade: "Plumber",
      phone: "",
      email: "",
      experience: 1,
      rating: 4.5,
      completedJobs: 0,
      status: "Active",
      location: "",
      languages: "Hindi",
      skills: "",
      verified: false,
      joinedDate: new Date().toISOString().split("T")[0],
    }
  );

  function set<K extends keyof Professional>(key: K, value: Professional[K]) {
    setForm(f => ({ ...f, [key]: value }));
  }

  function handleSave() {
    if (!form.name.trim() || !form.phone.trim() || !form.location.trim()) {
      toast.error("Please fill required fields: name, phone, and location.");
      return;
    }
    onSave(form);
    addLog({
      type: pro ? "edit" : "create",
      message: pro ? `Professional ${form.name} profile updated` : `New professional ${form.name} (${form.trade}) added`,
      proId: form.id,
    });
    toast.success(pro ? "Professional saved successfully" : `${form.name} added as ${form.trade}`);
    onClose();
  }

  return (
    <Dialog.Root open={isOpen} onOpenChange={open => !open && onClose()}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50" />
        <Dialog.Content asChild>
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50 bg-white dark:bg-slate-800 rounded-2xl shadow-xl w-full max-w-lg overflow-hidden"
          >
            <div className="flex items-center justify-between px-6 py-4 border-b border-border">
              <Dialog.Title className="font-semibold text-slate-900 dark:text-slate-100">
                {pro ? "Edit Professional" : "Add New Professional"}
              </Dialog.Title>
              <Dialog.Close asChild>
                <button className="text-slate-400 hover:text-slate-600"><X size={20} /></button>
              </Dialog.Close>
            </div>

            <div className="px-6 py-5 space-y-4 max-h-[75vh] overflow-y-auto">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Full Name *</label>
                  <input value={form.name} onChange={e => set("name", e.target.value)} className="w-full rounded-xl border border-border px-3 py-2.5 text-sm bg-white dark:bg-slate-700 dark:text-slate-100 outline-none focus:ring-2 focus:ring-ring" placeholder="e.g. Rohit Sharma" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Trade *</label>
                  <select value={form.trade} onChange={e => set("trade", e.target.value)} className="w-full rounded-xl border border-border px-3 py-2.5 text-sm bg-white dark:bg-slate-700 dark:text-slate-100 outline-none focus:ring-2 focus:ring-ring">
                    {TRADES.map(t => <option key={t}>{t}</option>)}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Phone *</label>
                  <input value={form.phone} onChange={e => set("phone", e.target.value)} className="w-full rounded-xl border border-border px-3 py-2.5 text-sm bg-white dark:bg-slate-700 dark:text-slate-100 outline-none focus:ring-2 focus:ring-ring" placeholder="+91 98765 43210" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Email</label>
                  <input value={form.email} onChange={e => set("email", e.target.value)} className="w-full rounded-xl border border-border px-3 py-2.5 text-sm bg-white dark:bg-slate-700 dark:text-slate-100 outline-none focus:ring-2 focus:ring-ring" placeholder="pro@homefix.in" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Location / Area *</label>
                  <input value={form.location} onChange={e => set("location", e.target.value)} className="w-full rounded-xl border border-border px-3 py-2.5 text-sm bg-white dark:bg-slate-700 dark:text-slate-100 outline-none focus:ring-2 focus:ring-ring" placeholder="e.g. South Delhi" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Experience (years)</label>
                  <input type="number" min={0} max={50} value={form.experience} onChange={e => set("experience", Number(e.target.value))} className="w-full rounded-xl border border-border px-3 py-2.5 text-sm bg-white dark:bg-slate-700 dark:text-slate-100 outline-none focus:ring-2 focus:ring-ring" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Skills / Specializations</label>
                <textarea value={form.skills} onChange={e => set("skills", e.target.value)} rows={2} className="w-full rounded-xl border border-border px-3 py-2.5 text-sm bg-white dark:bg-slate-700 dark:text-slate-100 outline-none focus:ring-2 focus:ring-ring resize-none" placeholder="e.g. Leak repair, pipe fitting, bathroom fixtures" />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Languages</label>
                  <input value={form.languages} onChange={e => set("languages", e.target.value)} className="w-full rounded-xl border border-border px-3 py-2.5 text-sm bg-white dark:bg-slate-700 dark:text-slate-100 outline-none focus:ring-2 focus:ring-ring" placeholder="Hindi, English" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">Status</label>
                  <select value={form.status} onChange={e => set("status", e.target.value as Professional["status"])} className="w-full rounded-xl border border-border px-3 py-2.5 text-sm bg-white dark:bg-slate-700 dark:text-slate-100 outline-none focus:ring-2 focus:ring-ring">
                    <option>Active</option>
                    <option>Busy</option>
                    <option>Offline</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center gap-3 pt-1">
                <button
                  type="button"
                  onClick={() => set("verified", !form.verified)}
                  className={`relative w-11 h-6 rounded-full transition-colors ${form.verified ? "bg-primary" : "bg-slate-200"}`}
                >
                  <span className={`absolute top-1 size-4 rounded-full bg-white shadow transition-transform ${form.verified ? "translate-x-5" : "translate-x-1"}`} />
                </button>
                <label className="text-sm text-slate-700 dark:text-slate-300 cursor-pointer" onClick={() => set("verified", !form.verified)}>
                  Background Verified
                </label>
              </div>
            </div>

            <div className="px-6 py-4 border-t border-border flex gap-3">
              <Dialog.Close asChild>
                <button className="flex-1 py-2.5 rounded-xl border border-border text-sm text-slate-600 hover:bg-slate-50 dark:hover:bg-slate-700 dark:text-slate-300">Cancel</button>
              </Dialog.Close>
              <button
                onClick={handleSave}
                className="flex-1 py-2.5 rounded-xl bg-primary text-white text-sm font-medium hover:bg-blue-700 flex items-center justify-center gap-2"
              >
                <Save size={15} /> {pro ? "Save Changes" : "Add Professional"}
              </button>
            </div>
          </motion.div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
