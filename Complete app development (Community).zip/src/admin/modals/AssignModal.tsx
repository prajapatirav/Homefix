import * as Dialog from "@radix-ui/react-dialog";
import { useState } from "react";
import { motion } from "motion/react";
import { X, Check, BadgeCheck } from "lucide-react";
import { toast } from "sonner";
import type { Booking, Professional, Customer } from "../../lib/types";
import type { ActivityLog } from "../../lib/types";

type Props = {
  booking: Booking | null;
  professionals: Professional[];
  getCustomer: (id: string) => Customer | undefined;
  onAssign: (bookingId: string, proId: string, proName: string) => void;
  onClose: () => void;
  addLog: (entry: Omit<ActivityLog, "id" | "timestamp">) => void;
};

export function AssignModal({ booking, professionals, getCustomer, onAssign, onClose, addLog }: Props) {
  const [selected, setSelected] = useState<string | null>(booking?.assignedProId ?? null);
  if (!booking) return null;

  const customer = getCustomer(booking.customerId);

  function handleAssign() {
    if (!selected) return;
    const pro = professionals.find(p => p.id === selected);
    if (!pro) return;
    onAssign(booking.id, selected, pro.name);
    addLog({ type: "assign", message: `Booking ${booking.id} assigned to ${pro.name}`, bookingId: booking.id, proId: pro.id });
    toast.success(`Assigned to ${pro.name}`, { description: `Booking ${booking.id} → Assigned` });
    onClose();
  }

  return (
    <Dialog.Root open={!!booking} onOpenChange={open => !open && onClose()}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50" />
        <Dialog.Content asChild>
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50 bg-white dark:bg-slate-800 rounded-2xl shadow-xl w-full max-w-lg overflow-hidden"
          >
            <div className="flex items-center justify-between px-6 py-4 border-b border-border">
              <Dialog.Title className="font-semibold text-slate-900 dark:text-slate-100">Assign Professional</Dialog.Title>
              <Dialog.Close asChild>
                <button className="text-slate-400 hover:text-slate-600"><X size={20} /></button>
              </Dialog.Close>
            </div>

            <div className="px-6 py-4 bg-blue-50 dark:bg-blue-950/30 border-b border-border">
              <p className="text-sm font-medium text-slate-900 dark:text-slate-100">{booking.service}</p>
              <p className="text-xs text-slate-500 mt-1">{booking.id} · {customer?.name} · {booking.date} {booking.slot}</p>
              {booking.notes && <p className="text-xs text-blue-600 mt-1 italic">Note: {booking.notes}</p>}
            </div>

            <div className="px-6 py-4 max-h-72 overflow-y-auto space-y-2">
              <p className="text-xs font-medium text-slate-500 uppercase tracking-wider mb-3">Select a professional</p>
              {professionals.map(p => {
                const isRelevant =
                  p.trade.toLowerCase().includes(booking.category.toLowerCase()) ||
                  booking.category.toLowerCase().includes(p.trade.toLowerCase());
                return (
                  <button
                    key={p.id}
                    onClick={() => setSelected(p.id)}
                    className={`w-full flex items-center gap-3 p-3 rounded-xl border text-left transition-all ${
                      selected === p.id ? "border-primary bg-blue-50 dark:bg-blue-950/40" : "border-border hover:bg-slate-50 dark:hover:bg-slate-700"
                    }`}
                  >
                    <div className="size-10 rounded-full bg-gradient-to-br from-blue-100 to-blue-200 flex items-center justify-center text-primary font-bold text-sm flex-shrink-0">
                      {p.name.split(" ").map(n => n[0]).join("")}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-medium dark:text-slate-100">{p.name}</p>
                        {p.verified && <BadgeCheck size={12} className="text-blue-500" />}
                        {isRelevant && <span className="text-[10px] bg-blue-100 text-blue-600 px-1.5 py-0.5 rounded">Recommended</span>}
                      </div>
                      <p className="text-xs text-slate-500">{p.trade} · {p.experience} yrs · ⭐ {p.rating} · {p.location}</p>
                    </div>
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      p.status === "Active" ? "bg-emerald-50 text-emerald-600" :
                      p.status === "Busy" ? "bg-amber-50 text-amber-600" :
                      "bg-slate-100 text-slate-500"
                    }`}>{p.status}</span>
                    {selected === p.id && <Check size={16} className="text-primary flex-shrink-0" />}
                  </button>
                );
              })}
            </div>

            <div className="px-6 py-4 border-t border-border flex gap-3">
              <Dialog.Close asChild>
                <button className="flex-1 py-2.5 rounded-xl border border-border text-sm text-slate-600 hover:bg-slate-50">Cancel</button>
              </Dialog.Close>
              <button
                onClick={handleAssign}
                disabled={!selected}
                className="flex-1 py-2.5 rounded-xl bg-primary text-white text-sm font-medium hover:bg-blue-700 disabled:opacity-40 disabled:cursor-not-allowed"
              >
                Confirm Assignment
              </button>
            </div>
          </motion.div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
