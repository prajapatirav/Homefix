import { useEffect, useState } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import { Command } from "cmdk";
import { LayoutDashboard, BriefcaseBusiness, UserCheck, Users, Activity, Plus, Search } from "lucide-react";
import type { AdminSection } from "../lib/types";
import { statusConfig } from "../lib/utils";
import type { Booking } from "../lib/types";

type Props = {
  open: boolean;
  onClose: () => void;
  setSection: (s: AdminSection) => void;
  onAddPro: () => void;
  recentBookings: Booking[];
};

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const NAV_ITEMS: [AdminSection, any, string][] = [
  ["dashboard", LayoutDashboard, "Dashboard"],
  ["bookings", BriefcaseBusiness, "Bookings"],
  ["professionals", UserCheck, "Professionals"],
  ["customers", Users, "Customers"],
  ["activity", Activity, "Activity Log"],
];

export function CommandPalette({ open, onClose, setSection, onAddPro, recentBookings }: Props) {
  function navigate(s: AdminSection) {
    setSection(s);
    onClose();
  }

  return (
    <Dialog.Root open={open} onOpenChange={o => !o && onClose()}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[200]" />
        <Dialog.Content className="fixed left-1/2 top-1/3 -translate-x-1/2 -translate-y-1/2 z-[200] w-full max-w-xl">
          <Dialog.Title className="sr-only">Command Palette</Dialog.Title>
          <Command className="bg-white dark:bg-slate-800 rounded-2xl shadow-2xl border border-border overflow-hidden">
            <div className="flex items-center gap-3 px-4 py-3 border-b border-border">
              <Search size={16} className="text-slate-400 flex-shrink-0" />
              <Command.Input
                placeholder="Search commands…"
                className="flex-1 bg-transparent text-sm outline-none text-slate-900 dark:text-slate-100 placeholder:text-slate-400"
              />
              <kbd className="text-xs text-slate-400 border border-border px-2 py-1 rounded-lg">ESC</kbd>
            </div>
            <Command.List className="max-h-80 overflow-y-auto p-2">
              <Command.Empty className="py-8 text-center text-sm text-slate-400">No results found.</Command.Empty>

              <Command.Group heading="Navigate" className="[&_[cmdk-group-heading]]:text-xs [&_[cmdk-group-heading]]:text-slate-400 [&_[cmdk-group-heading]]:uppercase [&_[cmdk-group-heading]]:tracking-wider [&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:pb-2 [&_[cmdk-group-heading]]:pt-3">
                {NAV_ITEMS.map(([s, Icon, label]) => (
                  <Command.Item
                    key={s}
                    value={label}
                    onSelect={() => navigate(s)}
                    className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-slate-700 dark:text-slate-200 cursor-pointer data-[selected=true]:bg-primary data-[selected=true]:text-white transition-colors"
                  >
                    <Icon size={15} />
                    {label}
                  </Command.Item>
                ))}
              </Command.Group>

              <Command.Group heading="Quick Actions" className="[&_[cmdk-group-heading]]:text-xs [&_[cmdk-group-heading]]:text-slate-400 [&_[cmdk-group-heading]]:uppercase [&_[cmdk-group-heading]]:tracking-wider [&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:pb-2 [&_[cmdk-group-heading]]:pt-3">
                <Command.Item
                  value="Add Professional"
                  onSelect={() => { onAddPro(); onClose(); }}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-slate-700 dark:text-slate-200 cursor-pointer data-[selected=true]:bg-primary data-[selected=true]:text-white transition-colors"
                >
                  <Plus size={15} />
                  Add New Professional
                </Command.Item>
                <Command.Item
                  value="Pending Bookings"
                  onSelect={() => navigate("bookings")}
                  className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-slate-700 dark:text-slate-200 cursor-pointer data-[selected=true]:bg-primary data-[selected=true]:text-white transition-colors"
                >
                  <BriefcaseBusiness size={15} />
                  View Pending Bookings
                </Command.Item>
              </Command.Group>

              {recentBookings.length > 0 && (
                <Command.Group heading="Recent Bookings" className="[&_[cmdk-group-heading]]:text-xs [&_[cmdk-group-heading]]:text-slate-400 [&_[cmdk-group-heading]]:uppercase [&_[cmdk-group-heading]]:tracking-wider [&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:pb-2 [&_[cmdk-group-heading]]:pt-3">
                  {recentBookings.slice(0, 5).map(b => {
                    const sc = statusConfig[b.status];
                    const StatusIcon = sc.icon;
                    return (
                      <Command.Item
                        key={b.id}
                        value={b.id + " " + b.service}
                        onSelect={() => navigate("bookings")}
                        className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-slate-700 dark:text-slate-200 cursor-pointer data-[selected=true]:bg-primary data-[selected=true]:text-white transition-colors"
                      >
                        <span className="font-mono text-xs font-bold">{b.id}</span>
                        <span className="flex-1 truncate">{b.service}</span>
                        <span className={`flex items-center gap-1 text-xs ${sc.color}`}>
                          <StatusIcon size={10} /> {b.status}
                        </span>
                      </Command.Item>
                    );
                  })}
                </Command.Group>
              )}
            </Command.List>
            <div className="px-4 py-2.5 border-t border-border flex gap-4 text-xs text-slate-400">
              <span><kbd className="border border-border rounded px-1.5 py-0.5 mr-1">↑↓</kbd>navigate</span>
              <span><kbd className="border border-border rounded px-1.5 py-0.5 mr-1">↵</kbd>select</span>
              <span><kbd className="border border-border rounded px-1.5 py-0.5 mr-1">ESC</kbd>close</span>
            </div>
          </Command>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
