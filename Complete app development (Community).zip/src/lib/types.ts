export type BookingStatus = "Pending" | "Assigned" | "In Progress" | "Completed" | "Cancelled";

export type Booking = {
  id: string;
  customerId: string;
  service: string;
  category: string;
  date: string;
  slot: string;
  status: BookingStatus;
  amount: number;
  address: string;
  assignedProId: string | null;
  notes: string;
  createdAt: string;
};

export type Professional = {
  id: string;
  name: string;
  trade: string;
  phone: string;
  email: string;
  experience: number;
  rating: number;
  completedJobs: number;
  status: "Active" | "Busy" | "Offline";
  location: string;
  languages: string;
  skills: string;
  verified: boolean;
  joinedDate: string;
};

export type Customer = {
  id: string;
  name: string;
  phone: string;
  email: string;
  address: string;
  totalBookings: number;
  totalSpent: number;
  joinedDate: string;
};

export type ActivityLog = {
  id: string;
  type: "create" | "assign" | "status" | "edit" | "delete";
  message: string;
  bookingId?: string;
  proId?: string;
  timestamp: string;
};

export type AdminSection = "dashboard" | "bookings" | "professionals" | "customers" | "activity";

export type Screen =
  | "splash" | "onboarding" | "login" | "otp" | "home" | "search"
  | "categories" | "services" | "serviceDetail" | "technician" | "address"
  | "schedule" | "review" | "payment" | "success" | "bookings" | "bookingDetails"
  | "tracking" | "notifications" | "offers" | "wallet" | "ratings" | "support"
  | "faq" | "profile" | "settings";

export type Service = {
  id: number;
  title: string;
  category: string;
  price: number;
  rating: number;
  duration: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  icon: any;
  desc: string;
};
