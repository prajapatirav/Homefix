import type { Booking, Professional, Customer, ActivityLog } from "./types";

export const initialProfessionals: Professional[] = [
  { id: "P001", name: "Ravi Kumar", trade: "Plumber", phone: "+91 98765 43210", email: "ravi@homefix.in", experience: 12, rating: 4.9, completedJobs: 1842, status: "Active", location: "South Delhi", languages: "Hindi, English", skills: "Leak repair, pipe fitting, bathroom fixtures, waterproofing", verified: true, joinedDate: "2022-03-15" },
  { id: "P002", name: "Meera Singh", trade: "Electrician", phone: "+91 99123 45678", email: "meera@homefix.in", experience: 8, rating: 4.8, completedJobs: 1124, status: "Busy", location: "West Delhi", languages: "Hindi", skills: "Switchboard repair, MCB, wiring, fan installation, inverter setup", verified: true, joinedDate: "2022-07-20" },
  { id: "P003", name: "Suresh Patel", trade: "Carpenter", phone: "+91 97654 32109", email: "suresh@homefix.in", experience: 15, rating: 4.7, completedJobs: 987, status: "Active", location: "East Delhi", languages: "Hindi, Gujarati", skills: "Door/window repair, furniture assembly, wardrobe fitting, polish work", verified: true, joinedDate: "2021-11-05" },
  { id: "P004", name: "Anjali Desai", trade: "AC Technician", phone: "+91 91234 56789", email: "anjali@homefix.in", experience: 6, rating: 4.8, completedJobs: 743, status: "Active", location: "North Delhi", languages: "Hindi, English", skills: "AC service, gas refill, coil cleaning, installation, troubleshooting", verified: true, joinedDate: "2023-01-10" },
  { id: "P005", name: "Dinesh Yadav", trade: "Painter", phone: "+91 96543 21098", email: "dinesh@homefix.in", experience: 10, rating: 4.6, completedJobs: 562, status: "Offline", location: "Central Delhi", languages: "Hindi", skills: "Interior painting, texture work, waterproofing, wall putty, wood polish", verified: true, joinedDate: "2022-05-18" },
];

export const initialCustomers: Customer[] = [
  { id: "C001", name: "Arya Mehta", phone: "+91 98765 43210", email: "arya@email.com", address: "B-42, Green Park, New Delhi", totalBookings: 7, totalSpent: 12490, joinedDate: "2024-01-15" },
  { id: "C002", name: "Rahul Sharma", phone: "+91 87654 32109", email: "rahul.sharma@email.com", address: "A-12, Lajpat Nagar, New Delhi", totalBookings: 4, totalSpent: 6840, joinedDate: "2024-03-22" },
  { id: "C003", name: "Priya Nair", phone: "+91 76543 21098", email: "priya.n@email.com", address: "C-8, Vasant Kunj, New Delhi", totalBookings: 11, totalSpent: 23450, joinedDate: "2023-09-08" },
  { id: "C004", name: "Karan Oberoi", phone: "+91 91234 56789", email: "karan.o@email.com", address: "D-55, Dwarka Sector 6, New Delhi", totalBookings: 2, totalSpent: 1890, joinedDate: "2025-01-30" },
  { id: "C005", name: "Sunita Verma", phone: "+91 94567 89012", email: "sunita.v@email.com", address: "E-22, Rohini Sector 15, New Delhi", totalBookings: 6, totalSpent: 9200, joinedDate: "2024-06-11" },
];

export const initialBookings: Booking[] = [
  { id: "HF-28419", customerId: "C001", service: "Split AC deep service", category: "AC Repair", date: "2026-06-23", slot: "4:30 PM", status: "Assigned", amount: 899, address: "B-42, Green Park, New Delhi", assignedProId: "P004", notes: "Customer requested eco-clean mode", createdAt: "2026-06-23T09:15:00" },
  { id: "HF-28420", customerId: "C002", service: "Switchboard & MCB repair", category: "Electrician", date: "2026-06-23", slot: "11:00 AM", status: "In Progress", amount: 349, address: "A-12, Lajpat Nagar, New Delhi", assignedProId: "P002", notes: "", createdAt: "2026-06-23T08:00:00" },
  { id: "HF-28421", customerId: "C003", service: "Complete home deep cleaning", category: "Cleaning", date: "2026-06-23", slot: "9:00 AM", status: "Pending", amount: 2499, address: "C-8, Vasant Kunj, New Delhi", assignedProId: null, notes: "3 BHK, 1400 sq ft", createdAt: "2026-06-22T20:30:00" },
  { id: "HF-28422", customerId: "C004", service: "Premium bathroom leak repair", category: "Plumber", date: "2026-06-24", slot: "10:00 AM", status: "Pending", amount: 499, address: "D-55, Dwarka Sector 6, New Delhi", assignedProId: null, notes: "Master bathroom sink leaking since 2 days", createdAt: "2026-06-23T11:00:00" },
  { id: "HF-27302", customerId: "C001", service: "Bathroom leak repair", category: "Plumber", date: "2026-06-18", slot: "10:00 AM", status: "Completed", amount: 499, address: "B-42, Green Park, New Delhi", assignedProId: "P001", notes: "", createdAt: "2026-06-17T14:00:00" },
  { id: "HF-27280", customerId: "C005", service: "Wardrobe door repair", category: "Carpenter", date: "2026-06-20", slot: "2:00 PM", status: "Completed", amount: 650, address: "E-22, Rohini Sector 15, New Delhi", assignedProId: "P003", notes: "2 sliding doors", createdAt: "2026-06-19T10:00:00" },
  { id: "HF-26881", customerId: "C001", service: "Home deep cleaning", category: "Cleaning", date: "2026-06-22", slot: "9:00 AM", status: "Cancelled", amount: 2499, address: "B-42, Green Park, New Delhi", assignedProId: null, notes: "", createdAt: "2026-06-20T16:00:00" },
];

export const initialActivityLog: ActivityLog[] = [
  { id: "A001", type: "assign", message: "Booking HF-28419 assigned to Anjali Desai", bookingId: "HF-28419", proId: "P004", timestamp: "2026-06-23T09:20:00" },
  { id: "A002", type: "assign", message: "Booking HF-28420 assigned to Meera Singh", bookingId: "HF-28420", proId: "P002", timestamp: "2026-06-23T08:05:00" },
  { id: "A003", type: "create", message: "New booking HF-28422 created by Karan Oberoi", bookingId: "HF-28422", timestamp: "2026-06-23T11:00:00" },
  { id: "A004", type: "status", message: "Booking HF-28420 status changed to In Progress", bookingId: "HF-28420", timestamp: "2026-06-23T11:15:00" },
  { id: "A005", type: "edit", message: "Professional Ravi Kumar profile updated", proId: "P001", timestamp: "2026-06-22T14:30:00" },
];
