import { useState, useEffect, useCallback } from "react";
import type { Booking, Professional, Customer, ActivityLog } from "./types";
import { initialBookings, initialProfessionals, initialCustomers, initialActivityLog } from "./data";

function usePersistedState<T>(key: string, initial: T): [T, (val: T | ((prev: T) => T)) => void] {
  const [state, setState] = useState<T>(() => {
    try {
      const stored = localStorage.getItem(key);
      return stored ? (JSON.parse(stored) as T) : initial;
    } catch {
      return initial;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(key, JSON.stringify(state));
    } catch {
      // storage full or unavailable — silently continue
    }
  }, [key, state]);

  return [state, setState];
}

export function useBookings() {
  const [bookings, setBookings] = usePersistedState<Booking[]>("hf_bookings", initialBookings);

  const addBooking = useCallback((b: Booking) => {
    setBookings(prev => [b, ...prev]);
  }, [setBookings]);

  const updateBooking = useCallback((id: string, patch: Partial<Booking>) => {
    setBookings(prev => prev.map(b => b.id === id ? { ...b, ...patch } : b));
  }, [setBookings]);

  return { bookings, setBookings, addBooking, updateBooking };
}

export function useProfessionals() {
  const [professionals, setProfessionals] = usePersistedState<Professional[]>("hf_professionals", initialProfessionals);

  const addProfessional = useCallback((p: Professional) => {
    setProfessionals(prev => [...prev, p]);
  }, [setProfessionals]);

  const updateProfessional = useCallback((id: string, patch: Partial<Professional>) => {
    setProfessionals(prev => prev.map(p => p.id === id ? { ...p, ...patch } : p));
  }, [setProfessionals]);

  const removeProfessional = useCallback((id: string) => {
    setProfessionals(prev => prev.filter(p => p.id !== id));
  }, [setProfessionals]);

  return { professionals, setProfessionals, addProfessional, updateProfessional, removeProfessional };
}

export function useCustomers() {
  const [customers] = usePersistedState<Customer[]>("hf_customers", initialCustomers);
  return { customers };
}

export function useActivityLog() {
  const [logs, setLogs] = usePersistedState<ActivityLog[]>("hf_activity", initialActivityLog);

  const addLog = useCallback((entry: Omit<ActivityLog, "id" | "timestamp">) => {
    const newEntry: ActivityLog = {
      ...entry,
      id: `A${Date.now()}`,
      timestamp: new Date().toISOString(),
    };
    setLogs(prev => [newEntry, ...prev].slice(0, 100));
  }, [setLogs]);

  return { logs, addLog };
}
