import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import { format, formatDistanceToNow } from "date-fns";
import type { BookingStatus } from "./types";
import {
  Clock, UserCheck, Loader2, CheckCircle2, X,
} from "lucide-react";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(iso: string): string {
  try {
    return format(new Date(iso), "dd MMM yyyy");
  } catch {
    return iso;
  }
}

export function formatRelative(iso: string): string {
  try {
    return formatDistanceToNow(new Date(iso), { addSuffix: true });
  } catch {
    return iso;
  }
}

export function generateBookingId(): string {
  return `HF-${Math.floor(10000 + Math.random() * 90000)}`;
}

export function generateProId(): string {
  return `P${String(Date.now()).slice(-3)}`;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const statusConfig: Record<BookingStatus, { color: string; bg: string; icon: any }> = {
  Pending: { color: "text-amber-600", bg: "bg-amber-50 border-amber-200", icon: Clock },
  Assigned: { color: "text-blue-600", bg: "bg-blue-50 border-blue-200", icon: UserCheck },
  "In Progress": { color: "text-violet-600", bg: "bg-violet-50 border-violet-200", icon: Loader2 },
  Completed: { color: "text-emerald-600", bg: "bg-emerald-50 border-emerald-200", icon: CheckCircle2 },
  Cancelled: { color: "text-red-500", bg: "bg-red-50 border-red-200", icon: X },
};

export const tradeColors: Record<string, string> = {
  Plumber: "bg-blue-100 text-blue-700",
  Electrician: "bg-yellow-100 text-yellow-700",
  Carpenter: "bg-orange-100 text-orange-700",
  "AC Technician": "bg-cyan-100 text-cyan-700",
  "AC Repair": "bg-cyan-100 text-cyan-700",
  Painter: "bg-purple-100 text-purple-700",
  Cleaner: "bg-green-100 text-green-700",
  Cleaning: "bg-green-100 text-green-700",
  "Pest Control": "bg-red-100 text-red-700",
  "Appliance Repair": "bg-slate-100 text-slate-700",
};

export const CHART_COLORS = ["#3b82f6", "#f59e0b", "#10b981", "#8b5cf6", "#ef4444", "#06b6d4", "#f97316", "#84cc16"];

export const TODAY = "2026-06-23";
