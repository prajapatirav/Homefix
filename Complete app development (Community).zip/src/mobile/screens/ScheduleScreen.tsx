import { addDays, format, isToday, isTomorrow } from "date-fns";
import { CalendarDays } from "lucide-react";
import type { Screen } from "../../lib/types";
import { TODAY } from "../../lib/utils";

const SLOTS = ["9:00 AM", "11:30 AM", "2:00 PM", "4:30 PM", "6:00 PM"];

type Props = {
  go: (s: Screen) => void;
  selectedDate: string;
  setSelectedDate: (d: string) => void;
  selectedSlot: string;
  setSelectedSlot: (s: string) => void;
};

export function ScheduleScreen({ go, selectedDate, setSelectedDate, selectedSlot, setSelectedSlot }: Props) {
  const baseDate = new Date(TODAY);
  const days = Array.from({ length: 7 }, (_, i) => addDays(baseDate, i));

  function dayLabel(d: Date) {
    if (isToday(d)) return "Today";
    if (isTomorrow(d)) return "Tomorrow";
    return format(d, "EEE");
  }

  return (
    <div className="flex h-full flex-col">
      <div className="sticky top-0 z-20 flex items-center gap-3 bg-background/90 px-5 pb-3 pt-12 backdrop-blur">
        <button onClick={() => go("address")} className="grid size-10 place-items-center rounded-full bg-white border border-border">
          <CalendarDays size={20} />
        </button>
        <h2 className="flex-1 font-['Roboto_Slab'] text-xl text-slate-950">Date & Time</h2>
      </div>

      <main className="flex-1 overflow-y-auto px-5 pb-28 space-y-6">
        {/* Date picker */}
        <div>
          <p className="text-sm font-medium text-slate-600 mb-3">Select Date</p>
          <div className="flex gap-2 overflow-x-auto pb-2">
            {days.map(d => {
              const iso = format(d, "yyyy-MM-dd");
              const selected = iso === selectedDate;
              return (
                <button
                  key={iso}
                  onClick={() => setSelectedDate(iso)}
                  className={`flex-shrink-0 flex flex-col items-center gap-1 w-16 py-3 rounded-2xl border transition-all ${
                    selected ? "bg-primary text-white border-primary" : "bg-white border-border text-slate-700 hover:bg-blue-50"
                  }`}
                >
                  <span className={`text-xs ${selected ? "text-blue-200" : "text-slate-500"}`}>{dayLabel(d)}</span>
                  <span className="text-lg font-bold">{format(d, "d")}</span>
                  <span className={`text-xs ${selected ? "text-blue-200" : "text-slate-400"}`}>{format(d, "MMM")}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Slot picker */}
        <div>
          <p className="text-sm font-medium text-slate-600 mb-3">Select Time Slot</p>
          <div className="grid grid-cols-3 gap-2">
            {SLOTS.map(slot => (
              <button
                key={slot}
                onClick={() => setSelectedSlot(slot)}
                className={`py-3 rounded-2xl border text-sm font-medium transition-all ${
                  selectedSlot === slot ? "bg-primary text-white border-primary" : "bg-white border-border text-slate-700 hover:bg-blue-50"
                }`}
              >
                {slot}
              </button>
            ))}
          </div>
        </div>

        <div className="bg-blue-50 rounded-2xl p-4">
          <p className="text-sm text-slate-600">Selected</p>
          <p className="font-['Roboto_Slab'] text-lg text-slate-900">{format(new Date(selectedDate), "EEEE, d MMMM yyyy")}</p>
          <p className="text-primary font-semibold">{selectedSlot}</p>
        </div>

        <button
          onClick={() => go("review")}
          className="w-full bg-primary text-primary-foreground min-h-12 rounded-2xl px-5 transition hover:brightness-95"
        >
          Continue
        </button>
      </main>
    </div>
  );
}
