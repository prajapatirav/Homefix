import { useTheme } from "next-themes";
import { ChevronLeft, Sun, Moon, Bell, Globe, ShieldCheck, Info, BadgeCheck } from "lucide-react";
import type { Screen } from "../../lib/types";

type Props = { go: (s: Screen) => void };

export function SettingsScreen({ go }: Props) {
  const { theme, setTheme } = useTheme();
  const isDark = theme === "dark";

  return (
    <div className="flex h-full flex-col">
      <div className="sticky top-0 z-20 flex items-center gap-3 bg-background/90 px-5 pb-3 pt-12 backdrop-blur">
        <button onClick={() => go("profile")} className="grid size-10 place-items-center rounded-full bg-white border border-border"><ChevronLeft size={20} /></button>
        <h2 className="flex-1 font-['Roboto_Slab'] text-xl text-slate-950">Settings</h2>
      </div>

      <main className="flex-1 overflow-y-auto px-5 pb-28 space-y-3">
        {/* Dark mode — functional */}
        <div className="rounded-[1.5rem] border border-border bg-card p-4 shadow-sm">
          <div className="flex items-center gap-3">
            {isDark ? <Moon className="text-primary" size={20} /> : <Sun className="text-primary" size={20} />}
            <span className="flex-1 font-medium">Dark Mode</span>
            <button
              onClick={() => setTheme(isDark ? "light" : "dark")}
              className={`relative w-11 h-6 rounded-full transition-colors ${isDark ? "bg-primary" : "bg-slate-200"}`}
            >
              <span className={`absolute top-1 size-4 rounded-full bg-white shadow transition-transform ${isDark ? "translate-x-5" : "translate-x-1"}`} />
            </button>
          </div>
          <p className="text-xs text-slate-500 mt-1 ml-8">Also toggleable in the admin panel header</p>
        </div>

        {[
          [Globe, "Language", "English"],
          [Bell, "Notifications", "All enabled"],
          [ShieldCheck, "Privacy", "Default settings"],
          [Info, "About HomeFix", "Version 2.0.0"],
        ].map(([Icon, label, sub]: any) => (
          <div key={label} className="rounded-[1.5rem] border border-border bg-card p-4 shadow-sm">
            <div className="flex items-center gap-3">
              <Icon className="text-primary" size={20} />
              <div className="flex-1">
                <p className="font-medium">{label}</p>
                <p className="text-xs text-slate-500">{sub}</p>
              </div>
              <BadgeCheck className="text-slate-300" size={18} />
            </div>
          </div>
        ))}
      </main>
    </div>
  );
}
