import { useEffect } from "react";
import { motion } from "motion/react";
import { Check } from "lucide-react";
// @ts-ignore
import confetti from "canvas-confetti";
import type { Screen } from "../../lib/types";

type Props = { go: (s: Screen) => void };

export function SuccessScreen({ go }: Props) {
  useEffect(() => {
    confetti({
      particleCount: 120,
      spread: 80,
      origin: { y: 0.55 },
      colors: ["#2563eb", "#38bdf8", "#10b981", "#f59e0b"],
    });
  }, []);

  return (
    <div className="flex h-full flex-col px-5 pt-16 space-y-6 overflow-y-auto pb-10">
      <div className="absolute left-1/2 top-3 z-40 h-6 w-32 -translate-x-1/2 rounded-full bg-slate-950 pointer-events-none" />
      <div className="grid place-items-center text-center flex-1">
        <motion.div
          initial={{ scale: 0.6, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", stiffness: 300 }}
          className="grid size-28 place-items-center rounded-full bg-emerald-100 text-emerald-600"
        >
          <Check size={54} />
        </motion.div>
        <motion.h1
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="mt-5 font-['Roboto_Slab'] text-3xl text-slate-950"
        >
          Booking confirmed!
        </motion.h1>
        <motion.p
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.35 }}
          className="text-slate-500 mt-2"
        >
          Your booking is now visible in the admin panel.
          <br />A professional will be assigned shortly.
        </motion.p>
      </div>

      <div className="space-y-3 pb-4">
        <button
          onClick={() => go("bookings")}
          className="w-full bg-primary text-primary-foreground min-h-12 rounded-2xl px-5 transition hover:brightness-95"
        >
          View my bookings
        </button>
        <button
          onClick={() => go("home")}
          className="w-full bg-white text-slate-700 border border-border min-h-12 rounded-2xl px-5 transition hover:bg-slate-50"
        >
          Back to home
        </button>
      </div>
    </div>
  );
}
