import { OTPInput, REGEXP_ONLY_DIGITS } from "input-otp";
import type { Screen } from "../../lib/types";

type Props = { go: (s: Screen) => void };

export function OtpScreen({ go }: Props) {
  return (
    <div className="flex h-full flex-col px-5 pt-16 space-y-6">
      <div className="absolute left-1/2 top-3 z-40 h-6 w-32 -translate-x-1/2 rounded-full bg-slate-950 pointer-events-none" />
      <div>
        <h1 className="font-['Roboto_Slab'] text-3xl text-slate-950">Verify OTP</h1>
        <p className="mt-1 text-slate-500 text-sm">Enter the 6-digit code sent to your number</p>
      </div>

      <OTPInput
        maxLength={6}
        pattern={REGEXP_ONLY_DIGITS}
        onComplete={() => go("home")}
        containerClassName="flex gap-3 justify-center"
        render={({ slots }) => (
          <>
            {slots.map((slot, i) => (
              <div
                key={i}
                className={`h-14 w-12 rounded-2xl border-2 text-xl font-bold flex items-center justify-center transition-all ${
                  slot.isActive ? "border-primary bg-blue-50" : "border-border bg-white"
                } ${slot.char ? "text-slate-900" : "text-transparent"}`}
              >
                {slot.char ?? slot.placeholderChar ?? "·"}
              </div>
            ))}
          </>
        )}
      />

      <p className="text-center text-sm text-slate-500">
        Didn't receive? <button className="text-primary font-medium">Resend in 30s</button>
      </p>

      <button
        onClick={() => go("home")}
        className="bg-primary text-primary-foreground min-h-12 rounded-2xl px-5 transition hover:brightness-95"
      >
        Verify & Continue
      </button>
    </div>
  );
}
