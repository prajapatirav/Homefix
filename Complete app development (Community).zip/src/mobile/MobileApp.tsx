import { useMemo, useState } from "react";
import { motion } from "motion/react";
import {
  Bell, BriefcaseBusiness, CalendarDays, Check, ChevronLeft, CreditCard, Gift,
  Headphones, Home, MapPin, Menu, MessageCircle, Search, Settings, ShieldCheck,
  Star, User, Wallet, Wrench, Zap, Droplets, Paintbrush, Bug, Snowflake, Hammer,
  Refrigerator, Camera, WashingMachine, Sparkles, Navigation, BadgeCheck, Plus, Trash2, UserCheck,
} from "lucide-react";
import { toast } from "sonner";
import type { Booking, Professional, ActivityLog, Screen } from "../lib/types";
import { generateBookingId } from "../lib/utils";
import { OtpScreen } from "./screens/OtpScreen";
import { SuccessScreen } from "./screens/SuccessScreen";
import { ScheduleScreen } from "./screens/ScheduleScreen";
import { SettingsScreen } from "./screens/SettingsScreen";

type Props = {
  bookings: Booking[];
  addBooking: (b: Booking) => void;
  professionals: Professional[];
  addLog: (entry: Omit<ActivityLog, "id" | "timestamp">) => void;
};

const categories = [
  ["Plumber", Droplets, 42], ["Electrician", Zap, 38], ["AC Repair", Snowflake, 29],
  ["Carpenter", Hammer, 31], ["Painter", Paintbrush, 18], ["Cleaning", Sparkles, 54],
  ["Pest Control", Bug, 16], ["Appliances", Wrench, 27], ["RO Service", Droplets, 12],
  ["Refrigerator", Refrigerator, 9], ["Washing", WashingMachine, 14], ["CCTV", Camera, 11],
] as const;

const services = [
  { id: 1, title: "Premium bathroom leak repair", category: "Plumber", price: 499, rating: 4.9, duration: "60-90 min", icon: Droplets, desc: "Leak tracing, sealing, pressure test and 30-day warranty." },
  { id: 2, title: "Split AC deep service", category: "AC Repair", price: 899, rating: 4.8, duration: "75 min", icon: Snowflake, desc: "Jet wash, coil cleaning, gas-level inspection and cooling report." },
  { id: 3, title: "Complete home deep cleaning", category: "Cleaning", price: 2499, rating: 4.7, duration: "4 hours", icon: Sparkles, desc: "Kitchen, bathrooms, floor scrubbing and balcony detailing." },
  { id: 4, title: "Switchboard & MCB repair", category: "Electrician", price: 349, rating: 4.8, duration: "45 min", icon: Zap, desc: "Fault diagnosis, safe replacement and load check." },
];

export function MobileApp({ bookings, addBooking, professionals, addLog }: Props) {
  const [screen, setScreen] = useState<Screen>("home");
  const [query, setQuery] = useState("");
  const [selectedService, setSelectedService] = useState(services[0]);
  const [selectedDate, setSelectedDate] = useState("2026-06-24");
  const [selectedSlot, setSelectedSlot] = useState("10:00 AM");

  const go = (s: Screen) => setScreen(s);
  const total = selectedService.price + 99 - 100;

  const myBookings = bookings.filter(b => b.customerId === "C001")
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const filtered = useMemo(
    () => services.filter(s => (s.title + s.category).toLowerCase().includes(query.toLowerCase())),
    [query]
  );

  function handlePayment() {
    const id = generateBookingId();
    const newBooking: Booking = {
      id,
      customerId: "C001",
      service: selectedService.title,
      category: selectedService.category,
      date: selectedDate,
      slot: selectedSlot,
      status: "Pending",
      amount: total,
      address: "B-42, Green Park, New Delhi",
      assignedProId: null,
      notes: "",
      createdAt: new Date().toISOString(),
    };
    addBooking(newBooking);
    addLog({ type: "create", message: `New booking ${id} created by Arya Mehta`, bookingId: id });
    toast.success("Booking confirmed!", { description: `${id} is now visible in admin` });
    go("success");
  }

  function MBtn({ children, onClick, variant = "primary" }: { children: React.ReactNode; onClick?: () => void; variant?: "primary" | "ghost" | "soft" }) {
    const cls =
      variant === "primary" ? "bg-primary text-primary-foreground shadow-lg shadow-blue-600/20" :
      variant === "soft" ? "bg-secondary text-secondary-foreground" :
      "bg-white text-slate-700 border border-border";
    return <button onClick={onClick} className={`${cls} min-h-12 rounded-2xl px-5 transition active:scale-[.98] hover:brightness-95`}>{children}</button>;
  }

  function Top({ title, back }: { title: string; back?: boolean }) {
    return (
      <div className="sticky top-0 z-20 flex items-center gap-3 bg-background/90 px-5 pb-3 pt-12 backdrop-blur">
        <button onClick={() => back ? go("home") : go("profile")} className="grid size-10 place-items-center rounded-full bg-white border border-border">
          {back ? <ChevronLeft size={20} /> : <Menu size={20} />}
        </button>
        <h2 className="flex-1 font-['Roboto_Slab'] text-xl text-slate-950">{title}</h2>
        <button onClick={() => go("notifications")} className="grid size-10 place-items-center rounded-full bg-white border border-border">
          <Bell size={18} />
        </button>
      </div>
    );
  }

  function BottomNav({ active }: { active: Screen }) {
    const items: [Screen, any, string][] = [
      ["home", Home, "Home"], ["bookings", BriefcaseBusiness, "Bookings"],
      ["notifications", Bell, "Alerts"], ["wallet", Wallet, "Wallet"], ["profile", User, "Profile"],
    ];
    return (
      <div className="absolute bottom-0 left-0 right-0 z-30 grid grid-cols-5 border-t border-border bg-white/95 px-2 pb-3 pt-2 backdrop-blur">
        {items.map(([s, Icon, label]) => (
          <button key={s} onClick={() => go(s)} className={`flex flex-col items-center gap-1 rounded-2xl py-2 text-[11px] ${active === s ? "text-primary bg-blue-50" : "text-slate-500"}`}>
            <Icon size={19} />{label}
          </button>
        ))}
      </div>
    );
  }

  function MCard({ children, className = "" }: { children: React.ReactNode; className?: string }) {
    return <div className={`rounded-[1.5rem] border border-border bg-card p-4 shadow-sm ${className}`}>{children}</div>;
  }

  function Scroll({ title, children, back = false }: { title: string; children: React.ReactNode; back?: boolean }) {
    return (
      <>
        <Top title={title} back={back} />
        <main className="h-[calc(100%-84px)] overflow-y-auto px-5 pb-28 space-y-4">{children}</main>
      </>
    );
  }

  function Section({ title, children, action, onAction }: { title: string; children: React.ReactNode; action?: string; onAction?: () => void }) {
    return (
      <section className="mt-6">
        <div className="mb-3 flex items-center justify-between">
          <h3 className="font-['Roboto_Slab'] text-lg">{title}</h3>
          {action && <button onClick={onAction} className="text-sm text-primary">{action}</button>}
        </div>
        {children}
      </section>
    );
  }

  function ServiceCard({ s }: { s: typeof services[0] }) {
    const Icon = s.icon;
    return (
      <MCard>
        <button onClick={() => { setSelectedService(s); go("serviceDetail"); }} className="flex w-full gap-3 text-left">
          <div className="grid size-14 place-items-center rounded-2xl bg-blue-50 text-primary"><Icon /></div>
          <div className="flex-1">
            <h4>{s.title}</h4>
            <p className="text-sm text-slate-500">{s.desc}</p>
            <p className="mt-2 text-sm"><Star className="inline fill-amber-400 text-amber-400" size={14} /> {s.rating} · ₹{s.price} · {s.duration}</p>
          </div>
        </button>
      </MCard>
    );
  }

  function Pro({ name, trade }: { name: string; trade?: string }) {
    return (
      <MCard className="text-center">
        <div className="mx-auto grid size-14 place-items-center rounded-full bg-gradient-to-br from-sky-200 to-blue-100 text-primary"><User /></div>
        <h4 className="mt-2">{name}</h4>
        <p className="text-xs text-slate-500">{trade || "8 yrs · 4.9 ★ · Verified"}</p>
      </MCard>
    );
  }

  const statusBadgeClass: Record<string, string> = {
    Pending: "bg-amber-50 text-amber-600",
    Assigned: "bg-blue-50 text-primary",
    "In Progress": "bg-violet-50 text-violet-600",
    Completed: "bg-emerald-50 text-emerald-600",
    Cancelled: "bg-red-50 text-red-500",
  };

  function BookingCard({ b }: { b: Booking }) {
    const pro = professionals.find(p => p.id === b.assignedProId);
    return (
      <MCard>
        <button onClick={() => go("bookingDetails")} className="w-full text-left">
          <div className="flex justify-between items-start">
            <h4 className="flex-1 pr-2">{b.service}</h4>
            <span className={`rounded-full px-3 py-1 text-xs shrink-0 ${statusBadgeClass[b.status] || "bg-blue-50 text-primary"}`}>{b.status}</span>
          </div>
          <p className="mt-1 text-sm text-slate-500">{b.id} · {b.date}, {b.slot}</p>
          {pro && <p className="mt-1 text-xs text-slate-500 flex items-center gap-1"><UserCheck size={11} /> {pro.name}</p>}
          <p className="mt-2 font-bold">₹{b.amount}</p>
        </button>
      </MCard>
    );
  }

  const activePros = professionals.filter(p => p.status === "Active");

  const HomeScreen = (
    <>
      <Top title="Hello Arya 👋" />
      <main className="h-[calc(100%-140px)] overflow-y-auto px-5 pb-24">
        <button onClick={() => go("address")} className="mb-3 flex items-center gap-2 text-sm text-slate-600"><MapPin size={16} /> Green Park, New Delhi</button>
        <button onClick={() => go("search")} className="mb-4 flex w-full items-center gap-3 rounded-2xl bg-white px-4 py-4 text-slate-400 border border-border"><Search size={18} /> Search for AC, plumbing, cleaning</button>
        <section className="rounded-[2rem] bg-slate-950 p-5 text-white">
          <p className="text-xs uppercase tracking-[.18em] text-sky-300">Monsoon Care</p>
          <h2 className="mt-2 font-['Roboto_Slab'] text-2xl">15% off leak-proofing & AC service</h2>
          <MBtn onClick={() => go("services")}>Book now</MBtn>
        </section>
        <Section title="Categories" action="View all" onAction={() => go("categories")}>
          <div className="grid grid-cols-4 gap-3">
            {categories.slice(0, 8).map(([n, Icon]) => (
              <button key={n} onClick={() => go("services")} className="rounded-2xl bg-white p-3 text-center text-[11px] text-slate-700 shadow-sm">
                <Icon className="mx-auto mb-2 text-primary" size={22} />{n}
              </button>
            ))}
          </div>
        </Section>
        <Section title="Popular services">
          <div className="space-y-3">{services.map(s => <ServiceCard key={s.id} s={s} />)}</div>
        </Section>
        <Section title="Top professionals">
          <div className="grid grid-cols-2 gap-3">
            {activePros.slice(0, 2).map(p => <Pro key={p.id} name={p.name} trade={`${p.experience} yrs · ⭐${p.rating} · Verified`} />)}
          </div>
        </Section>
        {myBookings.length > 0 && (
          <Section title="Recent bookings">
            <BookingCard b={myBookings[0]} />
          </Section>
        )}
      </main>
      <BottomNav active="home" />
    </>
  );

  const screens: Record<Screen, React.ReactNode> = {
    splash: HomeScreen,
    onboarding: HomeScreen,
    home: HomeScreen,
    login: (
      <Scroll title="Login" back>
        <h1 className="font-['Roboto_Slab'] text-3xl">Welcome back</h1>
        <p className="text-slate-500">Enter your mobile or email to receive a secure OTP.</p>
        <input className="w-full rounded-2xl border border-border bg-input-background px-4 py-4 outline-none focus:ring-2 focus:ring-ring" placeholder="Mobile number or email" />
        <MBtn onClick={() => go("otp")}>Send OTP</MBtn>
      </Scroll>
    ),
    otp: <OtpScreen go={go} />,
    search: (
      <Scroll title="Search" back>
        <input value={query} onChange={e => setQuery(e.target.value)} autoFocus className="w-full rounded-2xl border bg-white px-4 py-4" placeholder="Search services" />
        {(query ? filtered : services).map(s => <ServiceCard key={s.id} s={s} />)}
      </Scroll>
    ),
    categories: (
      <Scroll title="All Categories" back>
        <div className="grid grid-cols-2 gap-3">
          {categories.map(([n, Icon, c]) => (
            <MCard key={n}>
              <button onClick={() => go("services")} className="w-full text-left"><Icon className="text-primary" /><h4 className="mt-3">{n}</h4><p className="text-sm text-slate-500">{c} services</p></button>
            </MCard>
          ))}
        </div>
      </Scroll>
    ),
    services: (
      <Scroll title="Services" back>
        <div className="flex gap-2 overflow-x-auto">{["Rating 4+", "Price", "Distance", "Available today"].map(f => <span className="shrink-0 rounded-full bg-white px-4 py-2 text-sm border" key={f}>{f}</span>)}</div>
        {services.map(s => <ServiceCard key={s.id} s={s} />)}
      </Scroll>
    ),
    serviceDetail: (
      <Scroll title="Service Detail" back>
        <div className="rounded-[2rem] bg-gradient-to-br from-blue-600 to-sky-400 p-6 text-white">
          <Droplets size={46} />
          <h1 className="mt-8 font-['Roboto_Slab'] text-3xl">{selectedService.title}</h1>
          <p>{selectedService.desc}</p>
        </div>
        {["What's included", "Benefits", "Pricing breakdown"].map(t => (
          <MCard key={t}><h4>{t}</h4><p className="text-sm text-slate-500">Verified expert visit, HomeFix warranty, cleanup included.</p></MCard>
        ))}
        <MBtn onClick={() => go("technician")}>Choose technician</MBtn>
      </Scroll>
    ),
    technician: (
      <Scroll title="Technician" back>
        {activePros.slice(0, 2).map(p => <Pro key={p.id} name={p.name} trade={`${p.experience} yrs · ⭐${p.rating} · ${p.trade}`} />)}
        <MBtn onClick={() => go("address")}>Book Now</MBtn>
      </Scroll>
    ),
    address: (
      <Scroll title="Address" back>
        <MCard><MapPin className="text-primary" /><h4>Home — Green Park</h4><p className="text-sm text-slate-500">B-42, near metro gate 2, New Delhi</p></MCard>
        <div className="grid h-40 place-items-center rounded-[2rem] bg-blue-50 text-primary"><Navigation /> Map placeholder</div>
        <MBtn onClick={() => go("schedule")}><Plus className="inline" /> Use this address</MBtn>
      </Scroll>
    ),
    schedule: <ScheduleScreen go={go} selectedDate={selectedDate} setSelectedDate={setSelectedDate} selectedSlot={selectedSlot} setSelectedSlot={setSelectedSlot} />,
    review: (
      <Scroll title="Review Booking" back>
        <ServiceCard s={selectedService} />
        <MCard>
          <h4>Charges</h4>
          <p>Service ₹{selectedService.price}</p>
          <p>Convenience ₹99</p>
          <p>Coupon -₹100</p>
          <h3 className="mt-2">Total ₹{total}</h3>
        </MCard>
        <p className="text-xs text-slate-400">Date: {selectedDate} · Slot: {selectedSlot}</p>
        <MBtn onClick={() => go("payment")}>Proceed to payment</MBtn>
      </Scroll>
    ),
    payment: (
      <Scroll title="Payment" back>
        {["UPI", "Google Pay", "Cash After Service"].map((m, i) => (
          <MCard key={m}>
            <div className="flex items-center gap-3"><CreditCard className="text-primary" />{m}{i === 0 && <Check className="ml-auto text-emerald-500" />}</div>
          </MCard>
        ))}
        <MBtn onClick={handlePayment}>Pay ₹{total}</MBtn>
      </Scroll>
    ),
    success: <SuccessScreen go={go} />,
    bookings: (
      <>
        <Top title="My Bookings" />
        <main className="h-[calc(100%-140px)] overflow-y-auto px-5 pb-24 space-y-3">
          <div className="flex gap-2 overflow-x-auto">
            {["All", "Pending", "Assigned", "Completed"].map(x => (
              <span className="rounded-full bg-white px-4 py-2 text-sm border shrink-0" key={x}>{x}</span>
            ))}
          </div>
          {myBookings.length > 0
            ? myBookings.map(b => <BookingCard key={b.id} b={b} />)
            : <p className="text-slate-400 text-sm text-center pt-8">No bookings yet. Book a service!</p>
          }
        </main>
        <BottomNav active="bookings" />
      </>
    ),
    bookingDetails: (
      <Scroll title="Booking Details" back>
        {myBookings[0] && <BookingCard b={myBookings[0]} />}
        {["Booking Confirmed", "Technician Assigned", "On The Way", "Work Started", "Completed"].map((x, i) => (
          <MCard key={x}>
            <div className="flex gap-3">
              <Check className={i < (myBookings[0]?.status === "Assigned" ? 2 : i < 1 ? 1 : 0) ? "text-emerald-500" : "text-slate-300"} />{x}
            </div>
          </MCard>
        ))}
      </Scroll>
    ),
    tracking: (
      <Scroll title="Live Tracking" back>
        <div className="grid h-64 place-items-center rounded-[2rem] bg-slate-900 text-white"><MapPin /> Live map placeholder</div>
        <MCard><h4>{professionals.find(p => p.status === "Busy")?.name || "Technician"} is on the way</h4><p className="text-sm text-slate-500">ETA 18 minutes</p></MCard>
      </Scroll>
    ),
    notifications: (
      <>
        <Top title="Notifications" />
        <main className="h-[calc(100%-140px)] overflow-y-auto px-5 pb-24 space-y-3">
          {myBookings.filter(b => b.status === "Assigned").map(b => (
            <MCard key={b.id}>
              <div className="flex gap-3">
                <span className="mt-2 size-2 rounded-full bg-primary flex-shrink-0" />
                <div><h4>Technician assigned for {b.service}</h4><p className="text-sm text-slate-500">{b.id} · {b.date}</p></div>
              </div>
            </MCard>
          ))}
          {["15% monsoon coupon unlocked", "Payment receipt ready"].map(x => (
            <MCard key={x}><div className="flex gap-3"><span className="mt-2 size-2 rounded-full bg-primary flex-shrink-0" /><div><h4>{x}</h4><p className="text-sm text-slate-500">Just now</p></div></div></MCard>
          ))}
        </main>
        <BottomNav active="notifications" />
      </>
    ),
    offers: (
      <Scroll title="Offers" back>
        {["FIX15", "CLEAN250", "REFER500"].map(x => (
          <MCard key={x}><Gift className="text-primary" /><h4>{x}</h4><p className="text-sm text-slate-500">Apply and save on your next booking.</p></MCard>
        ))}
      </Scroll>
    ),
    wallet: (
      <>
        <Top title="Wallet" />
        <main className="h-[calc(100%-140px)] overflow-y-auto px-5 pb-24 space-y-3">
          <div className="rounded-[2rem] bg-primary p-6 text-white"><p>Wallet balance</p><h1 className="font-['Roboto_Slab'] text-4xl">₹1,240</h1><p className="text-blue-200 text-sm">Cashback ₹340 · Referral ₹900</p></div>
          {["Cashback from AC Service +₹90", "Payment for plumbing -₹499"].map(x => <MCard key={x}>{x}</MCard>)}
        </main>
        <BottomNav active="wallet" />
      </>
    ),
    ratings: (
      <Scroll title="Rate Service" back>
        <div className="flex justify-center gap-2">{Array.from({ length: 5 }).map((_, i) => <Star key={i} className="fill-amber-400 text-amber-400" size={34} />)}</div>
        <textarea className="min-h-36 w-full rounded-2xl border bg-white p-4" placeholder="Tell us about the service" />
        <MBtn onClick={() => go("home")}>Submit review</MBtn>
      </Scroll>
    ),
    support: (
      <Scroll title="Support" back>
        {[[MessageCircle, "Chat Support"], [Headphones, "Call Support"]].map(([Icon, x]: any) => (
          <MCard key={x}><Icon className="text-primary" /> {x}</MCard>
        ))}
      </Scroll>
    ),
    faq: (
      <Scroll title="FAQ" back>
        {["How are technicians verified?", "Can I reschedule?", "What if parts are required?"].map(q => (
          <MCard key={q}><h4>{q}</h4><p className="text-sm text-slate-500">HomeFix support confirms all details before additional charges.</p></MCard>
        ))}
      </Scroll>
    ),
    profile: (
      <>
        <Top title="Profile" />
        <main className="h-[calc(100%-140px)] overflow-y-auto px-5 pb-24 space-y-3">
          <MCard>
            <div className="flex items-center gap-3">
              <div className="grid size-16 place-items-center rounded-full bg-blue-100 text-primary"><User /></div>
              <div><h3>Arya Mehta</h3><p className="text-sm text-slate-500">arya@homefix.demo · +91 98765 43210</p></div>
            </div>
          </MCard>
          {[
            [MapPin, "Saved Addresses", "address"],
            [BriefcaseBusiness, "Booking History", "bookings"],
            [Wallet, "Wallet", "wallet"],
            [Settings, "Settings", "settings"],
            [Gift, "Offers & Coupons", "offers"],
            [Headphones, "Support Center", "support"],
          ].map(([Icon, x, s]: any) => (
            <MCard key={x}><button onClick={() => go(s)} className="flex w-full items-center gap-3"><Icon className="text-primary" />{x}</button></MCard>
          ))}
        </main>
        <BottomNav active="profile" />
      </>
    ),
    settings: <SettingsScreen go={go} />,
  };

  return (
    <div className="min-h-screen w-full bg-[radial-gradient(circle_at_20%_0%,#dbeafe,transparent_35%),linear-gradient(180deg,#f8fafc,#eef5ff)] p-3 sm:p-6 flex justify-center items-center">
      <div className="relative h-[860px] max-h-[calc(100vh-24px)] w-full max-w-[430px] overflow-hidden rounded-[2.4rem] border border-white/70 bg-background shadow-2xl shadow-slate-300/70">
        <div className="absolute left-1/2 top-3 z-40 h-6 w-32 -translate-x-1/2 rounded-full bg-slate-950" />
        {screens[screen]}
      </div>
    </div>
  );
}
