# HomeFix — App Quality Improvement Plan

## Context

The current HomeFix app is a 1,192-line single-file React prototype (`src/app/App.tsx`) that demonstrates both a customer-facing mobile app and an admin panel. While visually polished, it has major gaps that prevent it from feeling like a real product:

- All data is in-memory `useState` — resets on every page refresh
- Mobile app is hardcoded to one customer (C001); booking flow doesn't actually create bookings
- Admin dashboard has no charts (recharts is installed but unused)
- No feedback on admin actions (sonner toasts installed but unused)
- No dark mode, no command palette, no real OTP input — all installed but wired to nothing
- 50+ Radix UI components installed; all modals are hand-rolled divs instead

The goal is to implement the highest-impact improvements using the already-installed libraries, turning this into a convincingly functional prototype where mobile and admin are truly in sync.

---

## New File Structure

```
src/
  lib/
    types.ts          # All shared TypeScript types (extracted from App.tsx)
    data.ts           # All initial seed data arrays
    storage.ts        # usePersistedState hook + useBookings/useProfessionals/useCustomers/useActivityLog
    utils.ts          # statusConfig, tradeColors, cn(), formatDate(), generateBookingId()

  admin/
    AdminPanel.tsx                   # Shell: sidebar, header, dark mode toggle, Cmd+K trigger
    CommandPalette.tsx               # cmdk-powered quick navigation
    sections/
      DashboardSection.tsx           # Charts + stats + today's schedule
      BookingsSection.tsx            # Table with search/filter
      ProfessionalsSection.tsx       # Cards with search + earnings panel
      CustomersSection.tsx           # Customer table
      ActivityLogSection.tsx         # NEW: live activity feed
    modals/
      AssignModal.tsx                # Radix Dialog wrapper
      ViewBookingModal.tsx           # Radix Dialog wrapper
      ProModal.tsx                   # Radix Dialog wrapper
    charts/
      BookingsByDayChart.tsx         # recharts BarChart — last 7 days
      CategoryPieChart.tsx           # recharts PieChart — by trade
      RevenueLineChart.tsx           # recharts LineChart — cumulative revenue

  mobile/
    MobileApp.tsx                    # Phone shell + screen router + receives addBooking prop
    screens/
      OtpScreen.tsx                  # Uses input-otp component (replaces 6 manual inputs)
      SuccessScreen.tsx              # canvas-confetti on mount
      ScheduleScreen.tsx             # date-fns date picker (next 7 days)
      SettingsScreen.tsx             # Working dark mode toggle via next-themes

  app/
    App.tsx           # Root: ThemeProvider, Toaster, shared state hooks, mode toggle
```

---

## Prioritized Improvements

### Priority 1 — localStorage Persistence (`src/lib/storage.ts`)

Implement `usePersistedState<T>(key, initial)`: reads from `localStorage` on mount, writes via `useEffect` on every change. Export convenience hooks: `useBookings()`, `useProfessionals()`, `useCustomers()`, `useActivityLog()`.

This is the foundation — everything else depends on it. Without persistence, data resets on every refresh.

### Priority 2 — Mobile → Admin Booking Flow

The mobile `PaymentScreen` "Pay" button must actually create a booking:

```ts
const newBooking: Booking = {
  id: generateBookingId(),       // "HF-" + 5 random digits
  customerId: "C001",
  service: selectedService.title,
  category: selectedService.category,
  date: selectedDate,
  slot: selectedSlot,
  status: "Pending",
  amount: total,
  address: "B-42, Green Park, New Delhi",
  assignedProId: null,
  notes: "",
  createdAt: new Date().toISOString(),
};
addBooking(newBooking);
addActivityLog({ type: "create", message: `New booking ${newBooking.id} created by Arya Mehta` });
```

This makes the prototype feel real: customer books → appears in admin instantly as "Pending" → admin assigns → status syncs back to mobile.

### Priority 3 — Recharts Dashboard Charts (`src/admin/charts/`)

Three charts in `DashboardSection`:

- **BookingsByDayChart** — `BarChart` showing booking count per day for the last 7 days (derived from `bookings[].date` using `date-fns eachDayOfInterval`)
- **CategoryPieChart** — `PieChart` grouping bookings by `category`, with colors from the existing `tradeColors` palette
- **RevenueLineChart** — `LineChart` with `type="monotone"` showing cumulative daily revenue from completed bookings

Dashboard layout change:
- Row 1: 4 stat cards (unchanged)
- Row 2: BarChart (2/3 width) + PieChart (1/3 width)
- Row 3: RevenueLineChart (full width)
- Row 4: Today's Schedule timeline (2/3) + Available Professionals (1/3)

Today's Schedule: filter bookings where `date === today`, sort by slot, render as a vertical timeline with colored left borders by status and a pulsing dot for "In Progress".

### Priority 4 — Sonner Toasts (everywhere mutations happen)

Import `toast` from `sonner`. Wire `<Toaster />` in `App.tsx`. Call `toast` in:
- Assign booking: `toast.success("Assigned to [Name]", { description: "Status → Assigned" })`
- Status change: `toast.success("Status updated to ${status}")`
- Add/edit professional: `toast.success("Professional saved")`
- Delete professional: `toast.error("Professional removed")`
- Mobile booking created: `toast.success("Booking confirmed!")`
- Validation fail in ProModal: `toast.error("Please fill required fields")`

### Priority 5 — Radix Dialog Modals

Replace the three custom `fixed inset-0` overlay divs with `@radix-ui/react-dialog`:

```tsx
<Dialog.Root open={!!booking}>
  <Dialog.Portal>
    <Dialog.Overlay className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50" />
    <Dialog.Content className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 ...">
      {/* existing modal body */}
    </Dialog.Content>
  </Dialog.Portal>
</Dialog.Root>
```

Gains: focus trapping, Escape to close, `aria-dialog`, screen reader support — for free.

### Priority 6 — Activity Log Section (`src/admin/sections/ActivityLogSection.tsx`)

New `ActivityLog` type: `{ id, type: "create"|"assign"|"status"|"edit", message, timestamp }`.

Seed with 5 entries. Each admin/mobile mutation calls `addActivityLog(entry)`. Section renders a reverse-chronological feed using `date-fns formatDistanceToNow()` for relative times. Filter chips: All / Bookings / Professionals.

### Priority 7 — Command Palette (`src/admin/CommandPalette.tsx`)

Uses `cmdk` (`Command`, `CommandInput`, `CommandList`, `CommandItem`, `CommandGroup`). Opened by global `Cmd+K` keydown listener in `AdminPanel`. Wrapped in Radix Dialog.

Groups:
- **Navigate**: Dashboard, Bookings, Professionals, Customers, Activity
- **Quick Actions**: "Add Professional", "View pending bookings"
- **Recent**: Last 5 booking IDs with status

### Priority 8 — OTP Screen (`src/mobile/screens/OtpScreen.tsx`)

Replace 6 manual `<input maxLength={1}>` with `input-otp` package:

```tsx
import { OTPInput } from "input-otp"
// Single component, 6 slots, auto-focus next slot, auto-submit on complete
// On complete: navigate to "home"
```

### Priority 9 — Dark Mode (next-themes)

Wrap `App.tsx` in `<ThemeProvider attribute="class" defaultTheme="light">`. In `AdminPanel` header, add a Sun/Moon toggle button calling `useTheme().setTheme()`. In mobile `SettingsScreen`, wire the "Dark Mode" row toggle to the same hook. Since `ThemeProvider` is at root, toggling in either view affects both.

Add `dark:` Tailwind variants to admin cards (`dark:bg-slate-800 dark:border-slate-700`) and mobile background (`dark:bg-slate-950`).

### Priority 10 — canvas-confetti on Success

```ts
import confetti from "canvas-confetti"
// In SuccessScreen, useEffect on mount:
confetti({ particleCount: 120, spread: 80, origin: { y: 0.6 }, colors: ["#2563eb","#38bdf8","#10b981"] })
```

### Priority 11 — Professionals: Search + Earnings

Add a `useMemo`-filtered search (by name, trade, location) and status filter tabs to `ProfessionalsSection`.

Add earnings to each professional card:
```ts
const earnings = bookings
  .filter(b => b.assignedProId === p.id && b.status === "Completed")
  .reduce((sum, b) => sum + b.amount * 0.7, 0)  // 70% payout rate
```
Show `₹{earnings.toLocaleString()}` earned in the card footer.

### Priority 12 — Schedule Screen with date-fns

Replace the static date in `ScheduleScreen` with a horizontal scrollable date picker built using `date-fns addDays`, `format`, `isToday`, `isTomorrow`. Store `selectedDate` and `selectedSlot` in mobile state so they pass to the booking creation on payment.

---

## Data Flow (interconnection)

```
usePersistedState (localStorage)
       ↓
useBookings() ←──── MobileApp.PaymentScreen (creates new Pending booking)
       ↓                     ↓
Admin.BookingsSection    Admin.ActivityLog (sees "New booking created" event)
Admin.DashboardCharts    MobileApp.BookingsScreen (reflects status changes from admin)
       ↑
Admin assigns pro, changes status ──→ addActivityLog() ──→ ActivityLogSection
       ↓
sonner toast (every mutation confirmed)
```

---

## Files to Modify

| File | Change |
|------|--------|
| `src/app/App.tsx` | Add `ThemeProvider`, `Toaster`, switch to `useBookings()` etc. hooks |
| `src/app/App.tsx` | Extract mobile and admin into separate files |

## Files to Create

| File | Purpose |
|------|---------|
| `src/lib/storage.ts` | `usePersistedState` hook — the data spine |
| `src/lib/types.ts` | All shared types extracted from App.tsx |
| `src/lib/data.ts` | All initial seed data |
| `src/lib/utils.ts` | Helpers: `cn()`, `formatDate()`, `generateBookingId()`, `statusConfig`, `tradeColors` |
| `src/admin/AdminPanel.tsx` | Shell with dark mode toggle + Cmd+K |
| `src/admin/CommandPalette.tsx` | cmdk palette wrapped in Radix Dialog |
| `src/admin/sections/DashboardSection.tsx` | With recharts charts + Today's Schedule |
| `src/admin/sections/ActivityLogSection.tsx` | Live activity feed |
| `src/admin/sections/ProfessionalsSection.tsx` | With search + earnings panel |
| `src/admin/sections/BookingsSection.tsx` | Extracted from App.tsx |
| `src/admin/sections/CustomersSection.tsx` | Extracted from App.tsx |
| `src/admin/modals/AssignModal.tsx` | Radix Dialog version |
| `src/admin/modals/ViewBookingModal.tsx` | Radix Dialog version |
| `src/admin/modals/ProModal.tsx` | Radix Dialog + sonner validation toasts |
| `src/admin/charts/BookingsByDayChart.tsx` | recharts BarChart |
| `src/admin/charts/CategoryPieChart.tsx` | recharts PieChart |
| `src/admin/charts/RevenueLineChart.tsx` | recharts LineChart |
| `src/mobile/MobileApp.tsx` | With `addBooking` prop wired to payment |
| `src/mobile/screens/OtpScreen.tsx` | input-otp component |
| `src/mobile/screens/SuccessScreen.tsx` | canvas-confetti |
| `src/mobile/screens/ScheduleScreen.tsx` | date-fns date picker |
| `src/mobile/screens/SettingsScreen.tsx` | Working dark mode toggle |

---

## Verification

1. **Persistence**: Make a booking in mobile, refresh page → booking still appears in admin
2. **Booking sync**: Complete mobile payment flow → new "HF-XXXXX" booking appears in admin Bookings table with "Pending" status
3. **Assignment sync**: Assign a pro in admin → switch to Mobile view → booking shows "Assigned" status with pro name
4. **Charts**: Dashboard shows 3 working charts with real data derived from bookings
5. **Toasts**: Assign a pro → sonner toast appears confirming the action
6. **Dark mode**: Toggle in admin header → both admin and mobile switch themes
7. **Command palette**: Press Cmd+K in admin → palette opens with navigation options
8. **Confetti**: Complete booking payment in mobile → confetti fires on success screen
9. **Activity log**: Every action (booking created, pro assigned, status changed) appears in the Activity Log section
